#include <stdio.h>
int main()
{
	int a=1,n,k=1;
	scanf("%d",&n);
	for(;k!=0;)
	{
		if(a<=n)
		a=2*a;
		else
		a=2*(a-n)-1;
		k++;
		if(a==1)
		break;
	}
	printf("%d\n",k-1);
	return 0;
}
