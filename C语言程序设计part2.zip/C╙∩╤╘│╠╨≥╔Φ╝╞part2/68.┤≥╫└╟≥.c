#include <stdio.h>
#include <string.h>
#include <math.h>
int main()//û���������ô�Ѱ�
{
    double w,l,x0,y0,x,y;
    scanf("%lf %lf\n%lf %lf\n%lf %lf",&w,&l,&x0,&y0,&x,&y);
    char index[1001];
    scanf("%s",index);
    int i;
    int n=strlen(index);
    for(i=0;i<n;i++)
    {
        if(index[i]=='F')
            y0=-y0;
        if(index[i]=='B')
            y0=2*l-y0;
        if(index[i]=='L')
            x0=-x0;
        if(index[i]=='R')
            x0=2*w-x0;
    }
    double s=sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0));
    printf("%.4lf\n",s);
    return 0;
}
