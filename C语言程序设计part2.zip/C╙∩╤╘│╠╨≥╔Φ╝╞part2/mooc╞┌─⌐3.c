#include <stdio.h>
#include <string.h>
int main()
{
    char s[100],ss[100];
    gets(s);
    gets(ss);
    int m=strlen(s);
    int n=strlen(ss);
    int i,flag=0;
    for(i=0;i<n;i++)
    {
        if(ss[i]!=s[m-n+i])
        {
            flag=1;
            break;
        }
    }
    if(flag) printf("no.\n");
    else printf("yes.\n");
    return 0;
}
