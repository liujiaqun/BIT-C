#include <stdio.h>
int main()
{
    int a[10];
    scanf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6],&a[7],&a[8],&a[9]);
    int n,i;
    scanf("%d",&n);
    for(i=10-n;i<=9;i++)
        printf("%d,",a[i]);
    for(i=0;i<=8-n;i++)
        printf("%d,",a[i]);
    printf("%d",a[9-n]);
    return 0;
}
