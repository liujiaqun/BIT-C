#include <stdio.h>
int main()
{
	int i,k,isPrime;
	for(i=2;i<=100;i++)
{   isPrime=0;
    for(k=2;k<i;k++)
    {if(i%k==0)
    isPrime=1;
	}
	if(isPrime==0)
	printf("%d,",i);
}	


	return 0;
}
