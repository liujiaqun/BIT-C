#include <stdio.h>
int main()
{
	int n,i,j;
	for(i=1;i<=9;i++)
	printf("%-4d",i);
	printf("\n");
	for(i=1;i<=9;i++)
	for(j=1;j<=i;j++)
	{
	printf("%-4d",i*j);
	if(j==i)
	printf("\n");
    }
	return 0;
}
