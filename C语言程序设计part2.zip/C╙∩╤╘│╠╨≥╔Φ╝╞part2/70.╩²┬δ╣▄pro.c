//�������Ҫ���ǿ���scanf
#include <stdio.h>
#include <string.h>
void f(int d,char* s)
{
    int base=10000;
    int i;
    for(i=0;i<5;i++)
    {
        s[i]=d/base+'0';
        d=d%base;
        base/=10;
    }
}
int main()
{
    char a[200];
    char s[6];
    char str[5][3];//5��2��
    while(1)
    {
        int i;
        int d;
        scanf(" %d",&d);
        if(d==0) break;//����0�ͽ���ѭ��
        f(d,s);
        for(i=0;i<5;i++)
        {
            if(s[i]=='0') strcpy(str[i],"7D");
            if(s[i]=='1') strcpy(str[i],"50");
            if(s[i]=='2') strcpy(str[i],"37");
            if(s[i]=='3') strcpy(str[i],"57");
            if(s[i]=='4') strcpy(str[i],"5A");
            if(s[i]=='5') strcpy(str[i],"4F");
            if(s[i]=='6') strcpy(str[i],"6F");
            if(s[i]=='7') strcpy(str[i],"54");
            if(s[i]=='8') strcpy(str[i],"7F");
            if(s[i]=='9') strcpy(str[i],"5F");
        }
        printf("%s %s %s %s %s\n",str[0],str[1],str[2],str[3],str[4]);
    }
    return 0;
}
