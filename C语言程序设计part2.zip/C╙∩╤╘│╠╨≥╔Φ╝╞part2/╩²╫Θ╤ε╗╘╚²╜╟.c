#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    long long int a[n][n];
    a[0][0]=1;
    int i,j;
    for(i=1;i<=n-1;i++)
    {
        for(j=1;j<=i;j++)
           {
               a[i][j]=a[i-1][j-1]+a[i-1][j];
               printf("%lld\t",a[i][j]);
           }printf("\n");
    }
    return 0;
}
