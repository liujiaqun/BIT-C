#include <stdio.h>
#include <string.h>
int main()
{
    int n;
    scanf("%d",&n);
    int put[n][n],rotate[n][n];
    int i,j;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        scanf("%d",&put[i][j]);//&���ܶ���
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        rotate[i][j]=put[n-j-1][i];
    for(i=0;i<n;i++)
       {
           for(j=0;j<n;j++)
               printf("%-2d",rotate[i][j]);
           printf("\n");
       }
    return 0;

}
