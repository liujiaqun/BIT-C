#include <stdio.h>

int main()
{
	int n,i,a1=1,a2=1,a3,s=0;
	scanf("%d",&n);
	printf("%d\n%d\n",a1,a2);
	for(i=3;i<=n;i++)
	{
		a3=a1+a2;printf("%d\n",a3);
	    s=s+a3;a1=a2;a2=a3;
	}
	printf("s=%d\n",s);
	return 0;
}
