#include <stdio.h>
int main()
{
	int i=4,a[5]={0,1,2,3,4};
	for(i=4;i>=0;i--)
	{printf("a[%d]=%d\n",i,a[i]);
	}
	return 0;
}
