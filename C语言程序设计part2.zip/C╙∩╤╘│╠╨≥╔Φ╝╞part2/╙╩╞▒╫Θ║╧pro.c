#include <stdio.h>
int main()
{
	int s[10000];
	int a,b,c,d,i,j,k,l,n;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	for(i=0;i<=5;i++)
	for(j=0;j<=5-i;j++)
	for(k=0;k<=5-i-j;k++)
	for(l=0;l<=5-i-j-k;l++)
	{
		if(a*i+b*j+c*k+d*l)
		s[a*i+b*j+c*k+d*l]++;
	}
	for(n=1;n<10000;n++)
	{
		if(!s[n])
		break;
	}
	printf("The max is %d.\n",--n);
	return 0;
}
