#include <stdio.h>
int main()
{
	char c,x;
	int n,i,j;
	scanf("%c %d",&c,&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++)
		printf(" ");
		x=c+i-1;
		printf("%c",x);
		for(j=1;j<=2*(i-1)-1;j++)
		printf(" ");
		{if(i!=1)
		printf("%c",x);}
		printf("\n");
	}
	
	for(i=1;i<=n-1;i++)
	{
		for(j=1;j<=i;j++)
		printf(" ");
		x=c+n-i-1;
		printf("%c",x);
		for(j=1;j<=2*(n-i-1)-1;j++)
		printf(" ");
		{if(i!=(n-1))
		printf("%c",x);}
		printf("\n");
	}
	
	return 0;
}
