#include <stdio.h>
#include <string.h>
#include <math.h>
/*int main()
{
    char s[100];
    int k;
    scanf("%s",s);
    int n=strlen(s);
    int i;
    for(i=0;i<n;i++)
        k+=(s[n-1-i]-'0')*pow(10,i);
    printf("%d\n",k);
    return 0;
}*/
/*int main()
{


    while(1)
    {char s[100];
    scanf(" %s",s);
    printf("%s\n",s);}
    return 0;
}*/
int main()
{
    int m,n;
    scanf("%d,%d",&m,&n);
    printf("%d %d\n",m,n);
    return 0;
}
