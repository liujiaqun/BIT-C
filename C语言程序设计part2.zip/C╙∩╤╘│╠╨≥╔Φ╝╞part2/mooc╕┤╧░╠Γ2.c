/*#include <stdio.h>
int main()
{
    int a[10];
    scanf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6],&a[7],&a[8],&a[9]);
    int n,i;
    scanf("%d",&n);
    for(i=10-n;i<=9;i++)
        printf("%d,",a[i]);
    for(i=0;i<=8-n;i++)
        printf("%d,",a[i]);
    printf("%d",a[9-n]);
    return 0;
}*/
//����������ʵ��̫����
#include <stdio.h>
#include <string.h>
int main()
{
    char s[100];
    gets(s);
    int n=strlen(s);
    int i;
    if(!((s[n]>='a'&&s[n]<='z')||(s[n]>='A'&&s[n]<='Z')))
        n=n-1;
    if(n%2==0)
    {
        for(i=0;i<=n/2-1;i++)
        {
            if(s[i]>s[n-i-1])
            {
                char tmp=s[i];
                s[i]=s[n-i-1];
                s[n-i-1]=tmp;
            }
        }
    }
    if(n%2!=0)
    {
        for(i=0;i<=n/2-1;i++)
        {
            if(s[i]>s[n-i-1])
            {
                char tmp=s[i];
                s[i]=s[n-i-1];
                s[n-i-1]=tmp;
            }
        }
    }
    puts(s);
    return 0;
}
