#include <stdio.h>
#include <math.h>
int main()
{
	int counter=0,N,b,c;
	float a;
	scanf("%d",&N);
	for(c=3;c<=N;c++)
	for(b=2;b<=c;b++)
	{
		a=sqrt(c*c-b*b);
		if((int)a==a&&a<=b&&a!=0)
		counter++;
	}
	printf("%d\n",counter);
	return 0;
}
