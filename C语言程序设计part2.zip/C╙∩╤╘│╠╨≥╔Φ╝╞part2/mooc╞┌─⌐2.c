#include <stdio.h>
int main()
{
    int n,x;
    scanf("%d %d",&n,&x);
    int i,k;
    for(i=1;i<=n;i++)
   {   if(i<=n-2)
       {
           printf("%d",(x+i-1)%10);
           for(k=1;k<=n-1-i;k++)
               printf(" ");
           printf("%d\n",(x+2*n-i-1)%10);
       }
       else if(i==n-1)
       {
           printf("%d",(x+i-1)%10);
           printf("%d\n",(x+2*n-i-1)%10);
       }
       else
           printf("%d\n",(x+n-1)%10);
    }
    return 0;
}
