#include <stdio.h>
#include <string.h>
int main()
{
    char s[100];
    long long int k,sum=0;
    scanf("%s",s);
    int n=strlen(s);
    int i;
    long long count1,count2;
    for(i=0;i<n;i++)
    {
        if(s[i]=='A')
        {
            count1=0,count2=0;
            int flag1=i,flag2=i;
            while(flag1--)
            {
                if(s[flag1]=='Q')
                   count1++;

            }
            while(flag2<n)
            {
                if(s[flag2]=='Q')
                    count2++;
                flag2++;
            }
        }
        sum=sum+count1*count2;
    }
    k=sum%1000000007;
    printf("%lld\n",k);
}
