#include <stdio.h>
#define NUM 20
int main()
{
	int a[NUM]={1,1};
	int j;
	for(j=2;j<NUM;++j)
	a[j]=a[j-1]+a[j-2];
	for(j=0;j<NUM;j++)
	printf("%d ",a[j]);
	return 0;
}
