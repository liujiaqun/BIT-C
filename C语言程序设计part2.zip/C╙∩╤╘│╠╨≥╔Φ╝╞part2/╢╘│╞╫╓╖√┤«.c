#include <stdio.h>
#include <string.h>
int main()
{
    char s[100];
    scanf("%s",s);
    int n=strlen(s);
    int l=-1,h=n;
    int flag=1;
    while(l<=h)
    {
        l++;
        h--;
        if(s[l]!=s[h])
        {
            flag=0;
            break;
        }
    }
    if(flag) printf("YES\n");
    else printf("NO\n");
    return 0;
}
