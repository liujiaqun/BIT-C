#include <stdio.h>
int main()
{
	int n,i,s=0;
	scanf("%d",&n);
	for(i=1;;i++)
	{
		s=s+i;
		if(s>=n)
		break;
	}
	printf("%d\n",i);
	return 0;
}
