#include <stdio.h>
int main()
{
    int i,n,s,k,x;
    static int a[1000];
    scanf("%d",&n);
    for(i=1;i<n;i++){
    s=i*i;
    for(k=0;s>0;k++) {
    a[k]=s%10;
    s/=10;
    }
    for(x=0;x<k/2.0;x++) if(a[x]!=a[k-1-x]) break;
    if(x>=k/2.0) printf("%d\n",i);
    }
	return 0;
}
