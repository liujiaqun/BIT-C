//���Ƿֱ���S��H��D��C���������ң����ģ����鼰÷������������1�� 13������A��2������Q��K���Ƶ㣬���磺H1Ϊ����A��S13Ϊ����K��
//�ƾֽ���ʱ���ɸ���ҳ��е��йؼƷֵ���(�Ʒ���)����S12(��)�����к����ƣ�D11(��)��C10(�ӱ�)��16���ơ������ƾ����ò��ơ���δ������16����֮��һ�����Ե���ּ��㡣
//������C10�����ֻ�и����ƶ�û���κ����������+50�֣�������C10 ���������Ʒ��ƣ��������Ʒ������÷����ӱ����㡣
//�������Ʋ���ͬһ�ң���H1��H13��13���ƾ��Ը��ּƣ�����ֵΪ-50�� -2��-3��-4��-5��-6��-7��-8��-9��-10��-20��-30��-40������S12��D11�ֱ���-100��+100�ּ��㡣
//��������H1��H13����ͬһ�ң����������Σ�
    //���к�������+200�ּ��㡣
    //��S12��D11���ڳ������к�����֮һ�ң������ҵ�+500�֡�
    //��C10������ǰ������ԭ�����֮��
#include <stdio.h>
#include <string.h>
int f(int n,char str[][20])
{
    int sum=0,i,j,k,l;
    if((n==1)&&(strcmp(str[0],"C10")==0))//���ҽ���C10��ֻ��50����
        sum=50;
    else
    {
        for(i=0;i<n;i++)
        {
            if(strcmp(str[i],"C10")==0)//��C10��Ҳ�������ƣ�˫������
            {
                 if(n==16)
               sum==500;
               if(n==15)
               {
                   for(j=0;j<15;j++)
                       for(k=0;k<15;k++)
                       {
                           if((strcmp(str[j],"S12")==0)&&(strcmp(str[k],"D11")==0))
                           {
                               for(l=0;l<15;l++)
                               {
                                  if(strcmp(str[l],"H1")==0) sum+=-50;
                                  if(strcmp(str[l],"H2")==0) sum+=-2;
                                  if(strcmp(str[l],"H3")==0) sum+=-3;
                                  if(strcmp(str[l],"H4")==0) sum+=-4;
                                  if(strcmp(str[l],"H5")==0) sum+=-5;
                                  if(strcmp(str[l],"H6")==0) sum+=-6;
                                  if(strcmp(str[l],"H7")==0) sum+=-7;
                                  if(strcmp(str[l],"H8")==0) sum+=-8;
                                  if(strcmp(str[l],"H9")==0) sum+=-9;
                                  if(strcmp(str[l],"H10")==0) sum+=-10;
                                  if(strcmp(str[l],"H11")==0) sum+=-20;
                                  if(strcmp(str[l],"H12")==0) sum+=-30;
                                  if(strcmp(str[l],"H13")==0) sum+=-40;
                               }
                           }
                           else if(strcmp(str[k],"S12")==0) sum+=-294;
                           else sum+=-94;
                       }
               }
               if(n==14)
               {
                    for(j=0;j<14;j++)
                       for(k=0;k<14;k++)
                       {
                           if((strcmp(str[j],"S12")==0)||(strcmp(str[k],"D11")==0))
                           {
                               for(l=0;l<14;l++)
                               {
                                  if(strcmp(str[l],"H1")==0) sum+=-50;
                                  if(strcmp(str[l],"H2")==0) sum+=-2;
                                  if(strcmp(str[l],"H3")==0) sum+=-3;
                                  if(strcmp(str[l],"H4")==0) sum+=-4;
                                  if(strcmp(str[l],"H5")==0) sum+=-5;
                                  if(strcmp(str[l],"H6")==0) sum+=-6;
                                  if(strcmp(str[l],"H7")==0) sum+=-7;
                                  if(strcmp(str[l],"H8")==0) sum+=-8;
                                  if(strcmp(str[l],"H9")==0) sum+=-9;
                                  if(strcmp(str[l],"H10")==0) sum+=-10;
                                  if(strcmp(str[l],"H11")==0) sum+=-20;
                                  if(strcmp(str[l],"H12")==0) sum+=-30;
                                  if(strcmp(str[l],"H13")==0) sum+=-40;
                               }
                           }
                           else//����13��ȫ��
                           sum+=200;
                       }
               }
               else
               {
                   for(l=0;l<n;l++)
                       {
                        if(strcmp(str[l],"H1")==0) sum+=-50;
                        if(strcmp(str[l],"H2")==0) sum+=-2;
                        if(strcmp(str[l],"H3")==0) sum+=-3;
                        if(strcmp(str[l],"H4")==0) sum+=-4;
                        if(strcmp(str[l],"H5")==0) sum+=-5;
                        if(strcmp(str[l],"H6")==0) sum+=-6;
                        if(strcmp(str[l],"H7")==0) sum+=-7;
                        if(strcmp(str[l],"H8")==0) sum+=-8;
                        if(strcmp(str[l],"H9")==0) sum+=-9;
                        if(strcmp(str[l],"H10")==0) sum+=-10;
                        if(strcmp(str[l],"H11")==0) sum+=-20;
                        if(strcmp(str[l],"H12")==0) sum+=-30;
                        if(strcmp(str[l],"H13")==0) sum+=-40;
                        if(strcmp(str[l],"S12")==0) sum+=-100;
                        if(strcmp(str[l],"D11")==0) sum+=100;
                       }
               }
               sum=2*sum;
            }
            else//û��C10,�������15����
            {
               if(n==15)
               sum==500;
               if(n==14)
               {
                   for(j=0;j<14;j++)
                       for(k=0;k<14;k++)
                       {
                           if((strcmp(str[j],"S12")==0)&&(strcmp(str[k],"D11")==0))//����һ�ź���H
                           {
                               for(l=0;l<14;l++)
                               {
                                  if(strcmp(str[l],"H1")==0) sum+=-50;
                                  if(strcmp(str[l],"H2")==0) sum+=-2;
                                  if(strcmp(str[l],"H3")==0) sum+=-3;
                                  if(strcmp(str[l],"H4")==0) sum+=-4;
                                  if(strcmp(str[l],"H5")==0) sum+=-5;
                                  if(strcmp(str[l],"H6")==0) sum+=-6;
                                  if(strcmp(str[l],"H7")==0) sum+=-7;
                                  if(strcmp(str[l],"H8")==0) sum+=-8;
                                  if(strcmp(str[l],"H9")==0) sum+=-9;
                                  if(strcmp(str[l],"H10")==0) sum+=-10;
                                  if(strcmp(str[l],"H11")==0) sum+=-20;
                                  if(strcmp(str[l],"H12")==0) sum+=-30;
                                  if(strcmp(str[l],"H13")==0) sum+=-40;
                               }
                           }
                           else if(strcmp(str[j],"S12")==0) sum+=-294;
                           else sum+=-94;
                       }
               }
               if(n==13)
               {
                    for(j=0;j<13;j++)
                       for(k=0;k<13;k++)
                       {
                           if((strcmp(str[j],"S12")==0)||(strcmp(str[k],"D11")==0))//S12��D11�ڣ�����13���ǲ�ȫ��
                           {
                               for(l=0;l<13;l++)
                               {
                                  if(strcmp(str[l],"H1")==0) sum+=-50;
                                  if(strcmp(str[l],"H2")==0) sum+=-2;
                                  if(strcmp(str[l],"H3")==0) sum+=-3;
                                  if(strcmp(str[l],"H4")==0) sum+=-4;
                                  if(strcmp(str[l],"H5")==0) sum+=-5;
                                  if(strcmp(str[l],"H6")==0) sum+=-6;
                                  if(strcmp(str[l],"H7")==0) sum+=-7;
                                  if(strcmp(str[l],"H8")==0) sum+=-8;
                                  if(strcmp(str[l],"H9")==0) sum+=-9;
                                  if(strcmp(str[l],"H10")==0) sum+=-10;
                                  if(strcmp(str[l],"H11")==0) sum+=-20;
                                  if(strcmp(str[l],"H12")==0) sum+=-30;
                                  if(strcmp(str[l],"H13")==0) sum+=-40;
                               }
                           }
                           else//����13��ȫ��
                           sum+=200;
                       }
               }
               else//12�ż����£���������ȫ������
               {
                   for(l=0;l<n;l++)
                       {
                        if(strcmp(str[l],"H1")==0) sum+=-50;
                        if(strcmp(str[l],"H2")==0) sum+=-2;
                        if(strcmp(str[l],"H3")==0) sum+=-3;
                        if(strcmp(str[l],"H4")==0) sum+=-4;
                        if(strcmp(str[l],"H5")==0) sum+=-5;
                        if(strcmp(str[l],"H6")==0) sum+=-6;
                        if(strcmp(str[l],"H7")==0) sum+=-7;
                        if(strcmp(str[l],"H8")==0) sum+=-8;
                        if(strcmp(str[l],"H9")==0) sum+=-9;
                        if(strcmp(str[l],"H10")==0) sum+=-10;
                        if(strcmp(str[l],"H11")==0) sum+=-20;
                        if(strcmp(str[l],"H12")==0) sum+=-30;
                        if(strcmp(str[l],"H13")==0) sum+=-40;
                        if(strcmp(str[l],"S12")==0) sum+=-100;
                        if(strcmp(str[l],"D11")==0) sum+=100;
                       }
               }
            }
        }
    }
    return sum;
}
int main()
{
    int sum1=0,sum2=0,sum3=0,sum4=0;
    int n1,n2,n3,n4,i;
    while(1)
    {
        scanf("%d",&n1);
        char s1[n1][20];
        for(i=0;i<n1;i++)
            scanf("%s",s1[i]);
        scanf("%d",&n2);
        char s2[n2][20];
        for(i=0;i<n2;i++)
            scanf("%s",s2[i]);
        scanf("%d",&n3);
        char s3[n3][20];
        for(i=0;i<n3;i++)
            scanf("%s",s3[i]);
        scanf("%d",&n4);
        char s4[n4][20];
        for(i=0;i<n4;i++)
            scanf("%s",s4[i]);
        if((n1==0)&&(n2==0)&&(n3==0)&&(n4==0))
            break;
        if(n1!=0) sum1=f(n1,s1[n1][20]);
        if(n2!=0) sum2=f(n2,s2[n2][20]);
        if(n3!=0) sum3=f(n3,s3[n3][20]);
        if(n4!=0) sum4=f(n4,s4[n4][20]);
        if(sum1>0) printf("+%d ",sum1);
        else if(sum1<0) printf("-%d ",sum1);
        else printf("0 ");
        if(sum2>0) printf("+%d ",sum2);
        else if(sum2<0) printf("-%d ",sum2);
        else printf("0 ");
        if(sum3>0) printf("+%d ",sum3);
        else if(sum3<0) printf("-%d ",sum3);
        else printf("0 ");
        if(sum4>0) printf("+%d\n",sum4);
        else if(sum4<0) printf("-%d\n",sum4);
        else printf("0");
    }
     return 0;
}
