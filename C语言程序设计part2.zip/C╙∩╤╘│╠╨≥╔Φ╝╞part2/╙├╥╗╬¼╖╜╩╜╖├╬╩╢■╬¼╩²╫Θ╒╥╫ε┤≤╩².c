#include <stdio.h>
#include <stdlib.h>
#include <math.h> 
int main()
{
	int i=0,j=0,a[5][5],temp=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			a[i][j]=rand()%100;//������������鸳ֵ
			printf("%-5d",a[i][j]); 
		}
		printf("\n");
	}
	temp=a[0][0];
	for(i=0;i<5*5;i++)
	{
		if(temp<*(&a[0][0]+i))
		temp=*(&a[0][0]+i);
	}
	printf("\n�����Ϊ��%d",temp);
	return 0;
}
