#include <stdio.h>


int main()
{
	int x,a,b,c,d;
	scanf("%d",&x);
	1000*a+100*b+10*c+d==x;
	a>=1&&a<=9;
	b>=1&&b<=9;
	c>=1&&c<=9;
	d>=1&&d<=9;
	printf("%d\n",a);
	printf("%d\n",b);
	printf("%d\n",c);
	printf("%d\n",d);
	return 0;
}
