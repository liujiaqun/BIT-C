#include <stdio.h>
#define N 10
int main()
{
	int i,j,sum=0,m[N];
	float average;
	for(i=0;i<N;i++)
	{scanf("%d",&m[i]);
	sum+=m[i];
	}
	average=1.0*sum/N;
	printf("average=%f\n",average);
	for(j=0;j<N;j++)
	{if(m[j]<average)
	printf("%d ",m[j]);
	}
	return 0;
}
