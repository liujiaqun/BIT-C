#include <stdio.h>
int main()
{
	int i,j,a[3][4],n=1,b[4][3];
	for(i=0;i<3;i++)
	{for(j=0;j<4;j++)
	a[i][j]=n++;
	}
	for(i=0;i<3;i++)
	{for(j=0;j<4;j++)
	printf("%2d ",a[i][j]);
	printf("\n");
	}
	printf("\n");
	for(i=0;i<4;i++)//ע��i,j�൱�ڽ����� 
	{for(j=0;j<3;j++)
	b[i][j]=a[j][i];
	}
	for(i=0;i<4;i++)//ע��i,j�൱�ڽ����� 
	{for(j=0;j<3;j++)
	printf("%2d ",b[i][j]);
	printf("\n");
	}
	return 0;
}
