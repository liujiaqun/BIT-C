#include <stdio.h>

int main()
{
	int i,n,isPrime=1;
	scanf("%d",&n);
	for(i=2;i<n;i++)
	{if(n%i==0)
	isPrime=0;}
	if(isPrime==1)
	printf("Yes.\n");
	else
	printf("No.\n");
	return 0;
}
