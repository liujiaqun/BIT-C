/*ÅÅÐò²¢²åÈë
#include <stdio.h>
int main()
{
    int a[10];
    scanf("%d,%d,%d,%d,%d,%d,%d,%d,%d\n%d",&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6],&a[7],&a[8],&a[9]);
    int i,j;
    for(i=0;i<10;i++)
        for(j=i+1;j<10;j++)
    {
        if(a[i]>a[j])
        {
            int k=a[i];
            a[i]=a[j];
            a[j]=k;
        }
    }
    printf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9]);
    return 0;
}*/
/*奇数求和
#include <stdio.h>
int f(int n)
{
    if(n==1) return 1;
    return (2*n-1)+f(n-1);
}
int main()
{
    int n;
    scanf("%d",&n);
    printf("%d\n",f(n));
    return 0;
}*/
/*巧算自然数
#include <stdio.h>
int main()
{
    int step=1;
    int x;
    scanf("%d",&x);
    while(x!=1)
    {
        printf("%d,",x);
        step++;
        if(x%2==0)
            x/=2;
        else
            x=3*x+1;
    }
    printf("1\n");
    printf("step=%d\n",step);
    return 0;
}*/
#include <stdio.h>
int f(int village)
{
    if(village==7) return 2;
    return 2*(f(village+1)+1);
}
int main()
{
    int i;
    printf("sum=%d\n",f(0));
    for(i=1;i<=6;i++)
        printf("sell=%d,",f(i-1)-f(i));
    printf("sell=4,\n");//这里结尾的逗号要小心！
    return 0;
}
