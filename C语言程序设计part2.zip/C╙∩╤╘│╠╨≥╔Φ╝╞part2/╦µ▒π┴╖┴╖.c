#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    scanf("%d",&n);
    int a[100][100];
    int i,j,p;
    int k=1;
    i=1,j=0;
    for(p=1;p<=n/2;p++)
    {
        for(j=j+1;j<=n-p+1;j++)
            a[i][j]=k++;
        j--;
        for(i=i+1;i<=n-p+1;i++)
            a[i][j]=k++;
        i--;
        for(j=j-1;j>=p;j--)
            a[i][j]=k++;
        j++;
        for(i=i-1;i>=p+1;i--)
            a[i][j]=k++;
        i++;
    }
    if(n%2!=0) a[(n+1)/2][(n+1)/2]=n*n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            printf("%-3d",a[i][j]);
        printf("\n");
    }
    return 0;

}
