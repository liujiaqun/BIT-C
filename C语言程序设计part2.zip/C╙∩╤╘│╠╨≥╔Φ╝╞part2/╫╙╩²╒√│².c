#include <stdio.h>
int main()
{
	int k,i,a,b,c,d,e,sub1,sub2,sub3;
	scanf("%d",&k);
	for(i=10000;i<=30000;i++)
	{
		e=i%10;
		d=i/10%10;
		c=i/100%10;
		b=i/1000%10;
		a=i/10000%10;
		sub1=100*a+10*b+c;
		sub2=100*b+10*c+d;
		sub3=100*c+10*d+e;
		if(sub1%k==0&&sub2%k==0&&sub3%k==0)
		printf("%d\n",i);
	}
	return 0;
}
