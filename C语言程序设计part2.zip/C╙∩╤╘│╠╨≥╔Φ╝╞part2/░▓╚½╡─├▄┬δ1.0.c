#include <stdio.h>
#include <string.h>
int type(char *str)
{
    int n1=0,n2=0,n3=0,n4=0;
    int n=strlen(str);
    int i;
    int k=0;
    for(i=0;i<n;i++)
    {
        if((str[i]>='a')&&(str[i]<='z')) n1++;
        else if((str[i]>='A')&&(str[i]<='Z')) n2++;
        else if((str[i]>='0')&&(str[i]<='9')) n3++;
        else n4++;
    }
    if(n1>0) k++;
    if(n2>0) k++;
    if(n3>0) k++;
    if(n4>0) k++;
    return k;
}
int main()
{
    int x;
    scanf("%d\n",&x);
    while(x--)
    {
        char str[100];
        gets(str);
        int n=strlen(str);
        if(n<6) printf("Not Safe\n");
        else
        {
            int k=type(str);
            if(k==1) printf("Not Safe\n");
            else if(k==2) printf("Medium Safe\n");
            else printf("Safe\n");
        }
    }
    return 0;
}
