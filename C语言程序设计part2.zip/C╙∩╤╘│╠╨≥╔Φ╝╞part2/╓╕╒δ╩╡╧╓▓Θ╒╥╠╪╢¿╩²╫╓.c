#include <stdio.h>
int main()
{
    int a[10];
    int *p;
    int i;
    for(i=0;i<10;i++)
        scanf("%d",&a[i]);
    int x;
    scanf("%d",&x);
    p=a;
    int flag=0;
    for(i=0;i<10;i++)
    {
        if(*p==x)
        {
            flag=1;
            break;
        }
        p++;
    }
    if(flag) printf("%d\n",x);
    else printf("No\n");
    return 0;
}
