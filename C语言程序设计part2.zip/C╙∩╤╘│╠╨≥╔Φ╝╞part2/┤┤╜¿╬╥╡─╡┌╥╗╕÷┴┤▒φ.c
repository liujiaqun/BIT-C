#include <stdio.h>
#include <stdlib.h>
int main()
{
    struct node
    {
        char name[20];
        int score;
        struct node* link;
    };
    typedef struct node NODE;
    NODE* head;
    NODE* p;
    p=(NODE*)malloc(sizeof(NODE));
    p->link=NULL;
    head=p;
}
