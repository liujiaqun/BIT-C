#include <stdio.h>
int main()
{
	int i,j,n;
	char c;
	scanf("%d\n%c",&n,&c);
	//�����ʱ�������䣬��Ҫ��ո񣡣��� 
	for(i=1;i<=n;i++)
	{
		if(i==1||i==n)
		{
			printf("#");
			for(j=1;j<=n-2;j++)
			printf("-");
			printf("#");
		}
		if(i==2||i==n-1)
		{
			printf("|");
			for(j=1;j<=n-2;j++)
			{
				if(j%2==0) printf("-");
				else printf("*");
			}
			printf("|");
		}
		if(i>2&&i<n-1&&i%2!=0)
		{
			printf("||");
			for(j=1;j<=n-4;j++)
			printf("%c",c);
			printf("||");
		}
	    if(i>2&&i<n-1&&i%2==0)
	    {
	    	printf("|*");
			for(j=1;j<=n-4;j++)
			printf("%c",c);
			printf("*|");
		}
		printf("\n");
	} 
	return 0;
}
