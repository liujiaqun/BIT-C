#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int number[100];
char sign[50];
char num[100];
char str[150];
int main()
{
    scanf("%s",str);
    int n=strlen(str);
    int i;
    int j=0,m=0,k=0;
    int flag;
    for(i=0;i<n;i++)
    {
        if(str[i]=='+'||str[i]=='-'||str[i]=='*'||str[i]=='/')
        {
            sign[j]=str[i];
            j++;
        }
        else
        {
            do
            {
                num[m]=str[i];
                m++;
                i++;
            }while(str[i]!='+'&&str[i]!='-'&&str[i]!='*'&&str[i]!='/');
            number[k]=atoi(num);
            k++;
        }
        flag=j;
    }
    printf("%s\n",sign);
    for(i=0;i<n-flag;i++)
        printf("%d",number[i]);
}
