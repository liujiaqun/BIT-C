#include <stdio.h>
#define N 2
int main()
{
	int a[N][4],i,j,s=0;
	char c;
	for(i=0;i<N;i++)//����ɼ� 
	{
		for(j=0;j<4;j++)//����ѧ�ź����ųɼ�
		scanf("%d",&a[i][j]); 
	}
	printf("   NO.   MT   EN   PH   SUM   V   >90\n");
	printf("-------------------------------------\n");
	for(i=0;i<N;i++)
	{printf("%4d:",a[i][0]);
	for(s=0,j=1;j<4;j++)
	{   s += a[i][j];//�������ſγ��ܷ�
	printf("%4d",a[i][j]);
	if(a[i][1]>=90&&a[i][2]>=90&&a[i][3]>=90)
	c='yes';
	else
	c='no';
	printf("   %d   %d   %c\n",s,s/3,c); 
	}
	}
	return 0;
}
