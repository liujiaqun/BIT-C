#include <stdio.h>
int main()
{
	char c='Z';
	int i,j,n;
	printf("\nPlease Enter n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{for(j=1;j<=n+i-2;j++)
	if(j==n-i+1)
	printf("%c",c--);
	else printf(" ");
	printf("%c\n",c--);
	}
	for(i=1;i<n;i++)
	{for(j=1;j<=2*(n-1)-i;j++)
	if(j==i+1) 
	printf("%c",c--);
	else printf("");
	printf("%c\n",c--);
	}
	return 0;
}
