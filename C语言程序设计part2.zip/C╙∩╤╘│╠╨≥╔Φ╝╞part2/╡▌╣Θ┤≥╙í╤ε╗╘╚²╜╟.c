#include <stdio.h>
#include <string.h>
int f(int i,int j)
{
    int k;
    if(j==1||j==i)
        return 1;
    k=f(i-1,j-1)+f(i-1,j);
    return k;
}
int main()
{
    int n;
    scanf("%d",&n);
    int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n-i;j++)
            printf(" ");
        for(j=1;j<=i;j++)
            printf("%d ",f(i,j));
        printf("\n");
    }
    return 0;
}
