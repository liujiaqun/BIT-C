#include <stdio.h>

int main()
{
	char a;
	scanf("%c",&a);
	printf("The ASCII of character '%c' is %d.\n",a,a);
	return 0;
}
