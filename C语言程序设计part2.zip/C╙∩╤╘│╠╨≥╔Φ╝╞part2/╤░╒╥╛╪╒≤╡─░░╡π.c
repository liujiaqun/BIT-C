#include <stdio.h>
int main()
{
	int a[100][100],i,j,h,l,temp,x=0;
	scanf("%d%d",&h,&l);
	for(i=0;i<h;i++)
	{
		for(j=0;j<l;j++)
		scanf("%d",a[i]+j);
	}
	for(i=0;i<h;i++)
	{
		temp=0;
		for(j=0;j<l;j++)
		{
			if(a[i][j]>temp)
			temp=a[i][j];
		}
		a[i][l]=temp;
	}
	for(j=0;j<l;j++)
	{
		temp=0xffffff;//����ɶ������ 
		for(i=0;i<h;i++)
		{
			if(a[i][j]<temp)
			temp=a[i][j];
		}
		a[h][j]=temp;
	}
	for(i=0;i<h;i++)
	{
		for(j=0;j<l;j++)
		{
			if(a[i][j]==a[i][l]&&a[i][j]==a[h][j])
			{
				printf("Point:a[%d][%d]==%d\n",i,j,a[i][j]);
				x=1;
			}
		}
	}
	if(x==0)
	printf("No Point\n");
	return 0;
}
