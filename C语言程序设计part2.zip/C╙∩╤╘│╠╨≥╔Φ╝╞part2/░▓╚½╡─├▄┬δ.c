#include <stdio.h>
#include <string.h>
char check(char str[20])
{
 int n;
 n=strlen(str);
 if(n<6)
 return 'n';
 else
 {
  int a[4]={0,0,0,0};
  int kind=0,i;
  for(i=0;i<n;i++)
  {
   if(str[i]>='0'&&str[i]<='9') a[0]++;
   else if(str[i]>='a'&&str[i]<='z') a[1]++;
   else if(str[i]>='A'&&str[i]<='Z') a[2]++;
   else a[3]++;
  }
  for(i=0;i<4;i++)
  {
   if(a[i]!=0)
   kind++;
  }
  if(kind==1) return 'n';
  else if(kind==2) return 'm';
  else return 's';
 }
}
int main()
{
 int N;
 scanf("%d\n",&N);
 char str[20];
 for(int i=0;i<N;i++)
 {
  gets(str);
  char level;
  level=check(str);
  switch(level)
  {
   case 'n':printf("Not Safe\n");break;
   case 'm':printf("Medium Safe\n");break;
   case 's':printf("Safe\n");break;
  }
 }
 
}
