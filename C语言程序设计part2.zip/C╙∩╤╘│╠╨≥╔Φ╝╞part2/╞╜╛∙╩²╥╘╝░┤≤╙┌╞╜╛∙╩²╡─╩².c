#include <stdio.h>
#define N 4
int main()
{
	int a[N],sum=0,i,j;
	float average;
	for(i=0;i<N;i++)
	{scanf("%d",&a[i]);
	sum+=a[i];
	}
	average=1.0*sum/N;
	printf("average=%f\n",average);
	for(j=0;j<N;j++)
	{if(a[j]>average)
	printf("%d\n",a[j]);
	}
	return 0;
}
