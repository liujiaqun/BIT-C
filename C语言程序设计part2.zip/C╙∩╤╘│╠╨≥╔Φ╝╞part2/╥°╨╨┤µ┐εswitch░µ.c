#include <stdio.h>

int main()
{
	int year;
	float money,rate,total;
	printf("Input money and year\n");
	scanf("%f%d",&money,&year);
	switch(year)
	{
		case 1:
			rate=0.032;
			break;
		case 2:
			rate=0.041;
			break;
		case 3:
			rate=0.005;
			break;
		case 5:
			rate=0.0055;
			break;
		case 8:
			rate=0.0065;
			break;
		default:
			rate=0.0;
	}
	total=money+money*rate*12*year;
	printf("Total=%.2f\n",total);
	return 0;
}
