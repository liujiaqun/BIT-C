#include<stdio.h>
#include<string.h>
int get_type(char* str) {
    int n = strlen(str);
    int i;
	for(i=0; i<n; i++) {
        if(str[i] == '.') return 1;
        if(str[i] == '/') return 2;
        if(str[i] == '%') return 3;
    }
    return 0;

}

void formate(char* str, int start, int end, int op) {
    int l = start, h = end;
    while(l <= h) {
        char tmp = str[l];
        str[l] = str[h];
        str[h] = tmp;
        l++; h--;
    }

    l = start, h = end;
    if(op==1) {
        while(l<=h && str[l] == '0') l++;
    }
    else{
        while(l<=h && str[h] == '0') h--;
    }
    if(l<=h) {
        int i;
		for(i=l; i<=h; i++)
            printf("%c", str[i]);
    }
    else   printf("0");
}

int find(char* str, char ch) {
    int n = strlen(str);
    int i;
	for(i=0; i<n; i++) {
        if(str[i] == ch)
            return i;
    }
    return -1;
}

int main()
{
    char str[110];
    int n; scanf("%d", &n);
    while(n--) {
        scanf("%s",str);
        int n = strlen(str);
        int type = get_type(str);
        if(type == 0) {
            // zheng
            formate(str, 0, n-1, 1);
        }
        else if(type == 1) {
            // xiao
            int pos = find(str, '.');
            formate(str, 0, pos-1, 1);
            printf(".");
            formate(str, pos+1, n-1, 0);

        }
        else if(type == 2) {
            // fen
            int pos = find(str, '/');
            formate(str, 0, pos-1, 1);
            printf("/");
            formate(str, pos+1, n-1, 1);
        }
        else {
            formate(str, 0, n-2, 1);
            printf("%%");
        }
        printf("\n");
    }
    return 0;
}
