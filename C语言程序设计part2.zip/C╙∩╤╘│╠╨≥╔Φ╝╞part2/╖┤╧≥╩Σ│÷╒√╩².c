#include <stdio.h>
void reverse(int n)
{
    if(n<10)
        printf("%d\n",n);
    else
    {
        printf("%d",n%10);
        reverse(n/10);
    }
}
int main()
{
    int n;
    printf("please input a int number.\n");
    scanf("%d",&n);
    printf("the reverse number is\n");
    reverse(n);
    return 0;
}
