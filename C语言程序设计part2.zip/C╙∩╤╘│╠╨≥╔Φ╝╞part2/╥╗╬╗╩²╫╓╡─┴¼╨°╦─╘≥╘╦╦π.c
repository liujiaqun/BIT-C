#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int number[100];
char sign[50];
char num[100];
char str[150];
int add(int a,int b)
{
    return a+b;
}
int sub(int a,int b)
{
    return a-b;
}
int mul(int a,int b)
{
    return a*b;
}
int d(int a,int b)
{
    return a/b;
}
int main()
{
    while(1)
    {
    scanf("%s",str);
    int n=strlen(str);
    int i;
    int j=0,k=0;
    int flag;
    for(i=0;i<n;i++)
    {
        if(str[i]=='+'||str[i]=='-'||str[i]=='*'||str[i]=='/')
        {
            sign[j]=str[i];
            j++;
        }
        else
        {
            number[k]=str[i]-'0';
            k++;
        }
        flag=j;
    }
    int sum=0;
    for(i=0;i<flag;i++)
    {
        if(sign[i]=='*')
        {
            int a1=mul(number[i],number[i+1]);
            sum=sum+a1;
            number[i]=0;
            number[i+1]=0;
        }
        if(sign[i]=='/')
        {
            int a2=d(number[i],number[i+1]);
            sum=sum+a2;
            number[i]=0;
            number[i+1]=0;
        }
    }
    for(i=0;i<flag;i++)
    {
        if(sign[i]=='+')
        {
            sum=sum+add(number[i],number[i+1]);
            number[i]=0;
            number[i+1]=0;
        }
        if(sign[i]=='-')
        {
            sum=sum+sub(number[i],number[i+1]);
            number[i]=0;
            number[i+1]=0;
        }
    }
    printf("%d\n",sum);
    }
    return 0;
}
