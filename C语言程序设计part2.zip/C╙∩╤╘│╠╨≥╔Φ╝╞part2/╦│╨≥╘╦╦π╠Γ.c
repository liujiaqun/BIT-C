#include <stdio.h>
int main()
{
	int m,n;
char b;
scanf("%d %d",&m,&n);
b='%';
	printf("%d+%d=%d\n%d-%d=%d\n%d*%d=%d\n%d/%d=%d\n%d%c%d=%d\n",m,n,m+n,m,n,m-n,m,n,m*n,m,n,m/n,m,b,n,m%n);
	return 0;
}
