#include <stdio.h>
int main()
{
	int t,n,x,sum,len,max=-1001;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		sum=len=0;
		while(n--)
		{
			scanf("%d",&x);
			if(max<x)
			max=x;
			if(len+x>0)
			len=len+x;
			else
			len=0;
			if(sum<len)
			sum=len;
		}
		if(max<0)
		printf("%d\n",max);
		else
		printf("%d\n",sum);
	}
	return 0;
}
