#include <stdio.h>
int main()
{
	int n,x,y,z,t,a,b,c,d,e,f,g,h,i,j,k,l,m,o,p,q,r,s;
	scanf("%d",&n);
	switch(n)
	{
		case 1:
			printf("1\n2\n3\n4\n5\n6\n7\n8\n9\n");
			break;
		case 2:
			printf("No output.\n");
			break;
		case 3:
			for(x=100;x<=999;x++)
			{c=x%10;
			b=x/10%10;
			a=x/100%10;
			if(x==a*a*a+b*b*b+c*c*c)
			printf("%d\n",x);}
			break;
		case 4:
			for(y=1000;y<=9999;y++)
			{g=y%10;
			f=y/10%10;
			e=y/100%10;
			d=y/1000%10;
			if(y==d*d*d*d+e*e*e*e+f*f*f*f+g*g*g*g)
			printf("%d\n",y);}
			break;
		case 5:
			for(z=10000;z<=99999;z++)
			{l=z%10;
			k=z/10%10;
			j=z/100%10;
			i=z/1000%10;
			h=z/10000%10;
			if(z==h*h*h*h*h+i*i*i*i*i+j*j*j*j*j+k*k*k*k*k+l*l*l*l*l)
			printf("%d\n",z);}
			break;
		case 6:
			for(t=100000;t<=999999;t++)
			{s=t%10;
			r=t/10%10;
			q=t/100%10;
			p=t/1000%10;
			o=t/10000%10;
			m=t/100000%10;
			if(t==m*m*m*m*m*m+o*o*o*o*o*o+p*p*p*p*p*p+q*q*q*q*q*q+r*r*r*r*r*r+s*s*s*s*s*s)
			printf("%d\n",t);}
			break;
	}
	return 0;
}
