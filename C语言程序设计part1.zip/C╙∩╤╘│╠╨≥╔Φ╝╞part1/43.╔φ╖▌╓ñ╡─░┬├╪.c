#include <stdio.h>
#include <string.h>
int main()
{
    int N,i,Y,sum;
    char y;
    char s[20];
    int a[20];
    scanf("%d",&N);//��������Ȼ������������&!!!
    while(N--)
    {
        scanf("%s",s);
        int n=strlen(s);
        if(n==18)
        {
            for(i=0;i<=16;i++)
                a[i]=s[i]-'0';
            sum=7*a[0]+9*a[1]+10*a[2]+5*a[3]+8*a[4]+4*a[5]+2*a[6]+1*a[7]+6*a[8]+3*a[9]+7*a[10]+9*a[11]+10*a[12]+5*a[13]+8*a[14]+4*a[15]+2*a[16];
            Y=sum%11;
            switch(Y)
            {
            case 0:
                y='1';
                break;
            case 1:
                y='0';
                break;
            case 2:
                y='X';
                break;
            case 3:
                y='9';
                break;
            case 4:
                y='8';
                break;
            case 5:
                y='7';
                break;
            case 6:
                y='6';
                break;
            case 7:
                y='5';
                break;
            case 8:
                y='4';
                break;
            case 9:
                y='3';
                break;
            case 10:
                y='2';
                break;
            }
            if(s[17]==y)
                printf("Valid\n");
            else
                printf("Invalid\n");
        }
        if(n==15)
        {
            for(i=0;i<=14;i++)
                a[i]=s[i]-'0';
            if(a[12]==9&&a[13]==9&&(a[14]==6||a[14]==7||a[14]==8||a[14]==9))//18xx��İ�������
            {
                sum=7*a[0]+9*a[1]+10*a[2]+5*a[3]+8*a[4]+4*a[5]+1*2+8*1+6*a[6]+3*a[7]+7*a[8]+9*a[9]+10*a[10]+5*a[11]+8*a[12]+4*a[13]+2*a[14];
            Y=sum%11;
            switch(Y)
            {
            case 0:
                y='1';
                break;
            case 1:
                y='0';
                break;
            case 2:
                y='X';
                break;
            case 3:
                y='9';
                break;
            case 4:
                y='8';
                break;
            case 5:
                y='7';
                break;
            case 6:
                y='6';
                break;
            case 7:
                y='5';
                break;
            case 8:
                y='4';
                break;
            case 9:
                y='3';
                break;
            case 10:
                y='2';
                break;
            }
            printf("%d%d%d%d%d%d18%d%d%d%d%d%d%d%d%d%c\n",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],y);
            }
            else
            {
                sum=7*a[0]+9*a[1]+10*a[2]+5*a[3]+8*a[4]+4*a[5]+1*2+9*1+6*a[6]+3*a[7]+7*a[8]+9*a[9]+10*a[10]+5*a[11]+8*a[12]+4*a[13]+2*a[14];
            Y=sum%11;
            switch(Y)
            {
            case 0:
                y='1';
                break;
            case 1:
                y='0';
                break;
            case 2:
                y='X';
                break;
            case 3:
                y='9';
                break;
            case 4:
                y='8';
                break;
            case 5:
                y='7';
                break;
            case 6:
                y='6';
                break;
            case 7:
                y='5';
                break;
            case 8:
                y='4';
                break;
            case 9:
                y='3';
                break;
            case 10:
                y='2';
                break;
            }
            printf("%d%d%d%d%d%d19%d%d%d%d%d%d%d%d%d%c\n",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],y);

            }

        }
        if(n!=18&&n!=15)
            printf("Invalid\n");
    }
}
