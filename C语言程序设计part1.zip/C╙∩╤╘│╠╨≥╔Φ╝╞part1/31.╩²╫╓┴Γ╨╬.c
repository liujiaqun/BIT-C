#include <stdio.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++)
		printf(" ");
		for(j=1;j<=i;j++)
		printf("%-2d",n-j+1);
		for(j=n-i+2;j<=n;j++)
		printf("%-2d",j);
		printf("\n");
	}
	for(i=n-1;i>=1;i--)
	{
		for(j=1;j<=n-i;j++)
		printf(" ");
		for(j=1;j<=i;j++)
		printf("%-2d",n-j+1);
		for(j=n-i+2;j<=n;j++)
		printf("%-2d",j);
		printf("\n");	
	}
	return 0;
}
