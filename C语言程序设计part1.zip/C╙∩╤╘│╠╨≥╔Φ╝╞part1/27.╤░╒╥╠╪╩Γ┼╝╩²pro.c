#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
bool is_ok(int x){
	if(x%2) return 0;
	
	int len=0;
	bool use[10];
	memset(use,0,sizeof(use));
	while(x){
		len++;
		int k=x%10;
		if(use[k]) return 0;
		use[k]=1;
		x=x/10;
	}
	return len==4;
}

int main()
{
	int x,y,i;
	while(1){
		scanf("%d %d",&x,&y);
		if(x==0&&y==0) break;
		
		int sum=0;
		for(i=x;i<=y;i++){
			if(is_ok(i)){
				printf("%d ",i);
				sum++;
			}
		}
		if(sum==0) printf("Error\n");
	    else       printf("\ncounter=%d\n",sum);
	}
	return 0;
}
