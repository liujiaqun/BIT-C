#include <stdio.h>
int main()
{
	int x,y;
	scanf("%d",&x);
	y=x*x*x;
	printf("%d\n",y);
	return 0;
}
