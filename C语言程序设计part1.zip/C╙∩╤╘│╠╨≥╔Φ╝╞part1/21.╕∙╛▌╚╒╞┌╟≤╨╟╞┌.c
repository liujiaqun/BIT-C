#include <stdio.h>
int main()
{
	int y,m,d,a;
	scanf("%d%d%d",&y,&m,&d);//��������·ݺ�����
	if(y<=1900)
	printf("year is error.\n");
	else if(m<1||m>12)
	printf("month is error.\n");
	else if((m==1||m==3||m==5||m==7||m==8||m==10||m==12)&&d>31 )
	printf("day is error.\n");
	else if((m==4||m==6||m==9||m==11)&&d>30)
	printf("day is error.\n");
	else if((y%4==0&&y%100!=0||y%400==0)&&(m==2)&&(d>29))
	printf("day is error.\n");
	else if(!(y%4==0&&y%100!=0||y%400==0)&&(m==2)&&(d>28))
	printf("day is error.\n");
	else if(m==1)
	{a=(d+2*13+3*(13+1)/5+y-1+(y-1)/4-(y-1)/100+(y-1)/400)%7;
	if(a!=6)
	printf("%d\n",a+1);
	else
	printf("0\n");
	}
	else if(m==2)
	{a=(d+2*14+3*(14+1)/5+y-1+(y-1)/4-(y-1)/100+(y-1)/400)%7;
	if(a!=6)
	printf("%d\n",a+1);
	else
	printf("0\n");
	}
	
	else
	{a=(d+2*m+3*(m+1)/5+y+y/4-y/100+y/400)%7;//��ķ����ɭ��ʽ 
	if(a!=6)
	printf("%d\n",a+1);
	else
	printf("0\n");
	}
	return 0;
}
