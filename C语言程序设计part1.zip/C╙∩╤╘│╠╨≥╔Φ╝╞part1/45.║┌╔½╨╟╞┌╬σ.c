#include <stdio.h>
#include <string.h>
int main()
{
    int y,m,d,counter=0,i;
    int a[20];
    scanf("%d",&y);
    for(m=1;m<=12;m++)
    {
        if((m!=1)&&(m!=2))
        {
            d=(13+2*m+3*(m+1)/5+y+y/4-y/100+y/400)%7;
            if(d==4) {counter++;
            a[counter-1]=m;}
        }
        if(m==1)
        {
            d=(13+2*13+3*(13+1)/5+(y-1)+(y-1)/4-(y-1)/100+(y-1)/400)%7;
            if(d==4) {counter++;
            a[counter-1]=m;}
        }
        if(m==2)
        {
            d=(13+2*14+3*(14+1)/5+(y-1)+(y-1)/4-(y-1)/100+(y-1)/400)%7;
            if(d==4) {counter++;
            a[counter-1]=m;}
        }
    }
    if(counter>1)
    {
        printf("There are %d Black Fridays in year %d.\n",counter,y);
        printf("They are:\n");
        for(i=0;i<counter;i++)
            printf("%d/%d/13\n",y,a[i]);
    }
    if(counter==1)
    {printf("There is 1 Black Friday in year %d.\n",y);
    printf("It is:\n");
    printf("%d/%d/13\n",y,a[0]);}
    if(counter==0)
        printf("There is 0 Black Friday in year %d.\n",y);
}
