#include <stdio.h>
int main()
{
    int n,m,i,j;
    int flag=0;
    while(1)
    {
        scanf("%d%d",&n,&m);
        if(n==0&&m==0) return 0;
        else
        {
            flag++;
            if(flag!=1)
                printf("\n");//����ǳ����գ������ɶ�
            printf("Field #%d:\n",flag);
            int a[n][m];
            int b[n][m];
            char s[100];
            for(i=0;i<n;i++)
                {
                    scanf("%s",s);
                    for(j=0;j<m;j++)
                        a[i][j]=s[j];//������һ��һ�����ȥ�ˣ����Ҳ���˵����ַ�Ԫ��
                }
            char count='0';
            for(i=0;i<n;i++)
                for(j=0;j<m;j++)//�ֱ���һ��
            {
                if(a[i][j]=='*') b[i][j]='*';
                else
                {if((i==0)&&(j!=0)&&(j!=(m-1)))//��һ�г�����β����
                {
                    if(a[0][j-1]=='*') count++;
                    if(a[0][j+1]=='*') count++;
                    if(a[1][j]=='*') count++;
                    if(a[1][j-1]=='*') count++;
                    if(a[1][j+1]=='*') count++;
                    b[0][j]=count; count='0';//ǧ��ǵó�ʼ��������
                }
                if((i==n-1)&&(j!=0)&&(j!=(m-1)))//���һ�г�����β����
                {
                    if(a[i][j-1]=='*') count++;
                    if(a[i][j+1]=='*') count++;
                    if(a[i-1][j]=='*') count++;
                    if(a[i-1][j-1]=='*') count++;
                    if(a[i-1][j+1]=='*') count++;
                    b[i][j]=count; count='0';
                }
                if((i!=0)&&(i!=(n-1))&&(j!=0)&&(j!=(m-1)))//���Ĳ���
                {
                    if(a[i][j-1]=='*') count++;
                    if(a[i][j+1]=='*') count++;
                    if(a[i-1][j]=='*') count++;
                    if(a[i+1][j]=='*') count++;
                    if(a[i-1][j-1]=='*') count++;
                    if(a[i-1][j+1]=='*') count++;
                    if(a[i+1][j-1]=='*') count++;
                    if(a[i+1][j+1]=='*') count++;
                    b[i][j]=count; count='0';
                }
                if((j==0)&&(i!=0)&&(i!=(n-1)))//�����г�����β����
                {
                    if(a[i-1][0]=='*') count++;
                    if(a[i+1][0]=='*') count++;
                    if(a[i][1]=='*') count++;
                    if(a[i-1][1]=='*') count++;
                    if(a[i+1][1]=='*') count++;
                    b[i][0]=count; count='0';
                }
                if((j==(m-1))&&(i!=0)&&(i!=(n-1)))//�����г�����β����
                {
                    if(a[i-1][m-1]=='*') count++;
                    if(a[i+1][m-1]=='*') count++;
                    if(a[i][m-2]=='*') count++;
                    if(a[i-1][j-1]=='*') count++;
                    if(a[i+1][j-1]=='*') count++;
                    b[i][m-1]=count; count='0';
                }
                if((i==0)&&(j==0))//���Ͻ�
                {
                    if(a[i][j+1]=='*') count++;
                    if(a[i+1][j]=='*') count++;
                    if(a[i+1][j+1]=='*') count++;
                    b[0][0]=count; count='0';
                }
                if((i==0)&&(j==(m-1)))//���Ͻ�
                {
                    if(a[i][j-1]=='*') count++;
                    if(a[i+1][j]=='*') count++;
                    if(a[i+1][j-1]=='*') count++;
                    b[0][m-1]=count; count='0';
                }
                if((i==(n-1))&&(j==0))//���½�
                {
                    if(a[i-1][j]=='*') count++;
                    if(a[i][j+1]=='*') count++;
                    if(a[i-1][j+1]=='*') count++;
                    b[n-1][0]=count; count='0';
                }
                if((i==(n-1))&&(j==(m-1)))//���½�
                {
                    if(a[i-1][j]=='*') count++;
                    if(a[i][j-1]=='*') count++;
                    if(a[i-1][j-1]=='*') count++;
                    b[n-1][m-1]=count; count='0';
                }
                }

            }
            for(i=0;i<n;i++)
            {
                for(j=0;j<m;j++)
                    printf("%c",b[i][j]);
                printf("\n");
            }
        }
    }return 0;
}
