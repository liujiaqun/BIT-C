#include <stdio.h>
int main()
{
	int a,n,i=1,t=1;
	scanf("%d%d",&a,&n);
	while(i<=n)
	{t=t*a%1000;
	i++;
	}
	if(t!=0)
	printf("The last 3 numbers is %d.\n",t);
	else
	printf("The last 3 numbers is 000.\n");
	return 0;
}
