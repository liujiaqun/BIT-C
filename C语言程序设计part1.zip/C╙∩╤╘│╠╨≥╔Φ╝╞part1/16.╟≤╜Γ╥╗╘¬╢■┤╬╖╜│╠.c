#include <stdio.h>
#include <math.h>


int main()
{
	double a,b,c,d,x1,x2,x,m,n;
	scanf("%lf%lf%lf",&a,&b,&c);
	d=b*b-4*a*c;
	if(a==0&&b==0)
	printf("Input error!\n");
	if(a==0&&b!=0&&c!=0)
	printf("x=%.6lf\n",x=(-c)/b);
	if(a==0&&b!=0&&c==0)
	printf("x=%.6lf\n",x=c/b);
	if(a!=0&&b==0&&c<0)
	{x=sqrt((-c)/a);
	printf("x1=%.6lf\nx2=-%.6lf\n",x,x);
    }
    if(a!=0&&b==0&&c>0)
    {x=sqrt((c)/a);
    printf("x1=%.6lfi\nx2=-%.6lfi\n",x,x);
	}
    if(a!=0&&b==0&&c==0)
    printf("x1=x2=%.6lf\n",x=sqrt(c/a));
    if(a!=0&&b!=0&&d==0)
    {x=(-b)/(2*a);
    printf("x1=x2=%.6lf\n",x);
	}
    if(a!=0&&b!=0&&d>0)
    {x1=(-b+sqrt(d))/(2*a);
    x2=(-b-sqrt(d))/(2*a);
    printf("x1=%.6lf\nx2=%.6lf\n",x1,x2);
	}
	if(a!=0&&b!=0&&d<0)
	{n=(sqrt(-d)/(2*a));
	m=(-b)/(2*a);
	printf("x1=%.6lf+%.6lfi\nx2=%.6lf-%.6lfi\n",m,n,m,n);
	}
	return 0;
}
