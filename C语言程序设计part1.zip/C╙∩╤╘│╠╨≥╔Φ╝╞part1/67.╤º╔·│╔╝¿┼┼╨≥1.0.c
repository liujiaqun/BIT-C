#include <stdio.h>
#include <string.h>
#include <math.h>
struct STU
{
    char name[25];
    int score;
};
typedef struct STU STU;
STU stu[1007];
int n;
// int cmp(STU  a, STU b) {
//     // if(a.score  == b.score)
//     //     return strcmp(a.name, b.name) <= 0;
//     return  a.score < b.score;
// }
int find(char* str, char ch) {
    for(int i=0; i<strlen(str); i++)
        if(ch == str[i])
            return i;
    return -1;
}
int to_int(char* str) {
    int base = 0;
    for(int i=0; i<strlen(str); i++)
        base = base*10 + str[i] - '0';
    return base;
}
int main()
{
    scanf("%d", &n);
    for(int i=0; i<n; i++) {
        scanf(" %s",  stu[i].name);
        int pos = find(stu[i].name, ',');
        //stu[i].name[pos] = '\0';
        stu[i].score = to_int(stu[i].name + pos + 1);


    }
    for(int i=0; i<n-1; i++) {
        for(int j=0; j<n-1-i; j++)
            if(stu[j].score < stu[j+1].score) {
                STU tmp = stu[j];
                stu[j] = stu[j+1];
                stu[j+1] = tmp;
            }
    }
    for(int i=0; i<n; i++)
        printf("%s\n", stu[i].name);
    return  0;
}
