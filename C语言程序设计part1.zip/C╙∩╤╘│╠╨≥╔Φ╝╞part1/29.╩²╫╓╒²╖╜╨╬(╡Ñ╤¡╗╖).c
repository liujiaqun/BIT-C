#include <stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	for(i=1;i<=n*n;i++)
	{
		printf("%3d",i);
		if(i%n==0)
		printf("\n");
	}	
return 0;
}
