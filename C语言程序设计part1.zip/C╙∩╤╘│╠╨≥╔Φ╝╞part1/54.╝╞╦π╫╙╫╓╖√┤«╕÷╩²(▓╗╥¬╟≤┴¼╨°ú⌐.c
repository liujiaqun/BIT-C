#include <stdio.h>
#include <string.h>
int main()
{
    char s[100],s1[20];
    scanf("%s\n%s",s,s1);
    int n=strlen(s),n1=strlen(s1);
    int i,j;
    int flag=0;
    for(i=0;i<=n-n1;i++)
        {
            int count=0;
            for(j=0;j<n1;j++)
            {
               if(s[i+j]==s1[j])
                  count++;
             }
             if(count==n1)
                flag++;
        }
    printf("%d\n",flag);
    return 0;
}
