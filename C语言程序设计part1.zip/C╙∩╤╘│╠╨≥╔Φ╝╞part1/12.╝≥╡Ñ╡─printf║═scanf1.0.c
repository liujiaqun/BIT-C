#include <stdio.h>

int main()
{
	int a,x;
	scanf("%d",&a);
	x=a;
	printf("x=%d,x=%o,x=%x\n",x,x,x);
	return 0;
}
