#include <stdio.h>

int main()
{
	int x;
	scanf("%d",&x);
	printf("x=%d,x=%o,x=%x\n",x,x,x);
	
	return 0;
}
