#include <stdio.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=1;j<=n;j++)
		printf(" %2d",i*n+j);
		if(i!=n-1)
		printf("\n");
	}
	printf("\n");
	return 0;
}
