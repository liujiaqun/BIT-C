#include <stdio.h>
#include <stdlib.h>
#include <math.h> 


int main()
{
	int a,b;
	float d1,d2,degree;
	scanf("%d %d",&a,&b);
	d1=a*30+b*0.5;
	d2=b*6;
	degree=fabs(d1-d2);
	printf("At %d:%02d the angle is %.1f degrees.\n",a,b,degree=(degree>180)?(360-degree):degree);
	return 0;
}
