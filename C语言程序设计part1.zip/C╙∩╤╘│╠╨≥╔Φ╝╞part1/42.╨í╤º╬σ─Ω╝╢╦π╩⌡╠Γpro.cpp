#include <stdio.h>
#include <string.h>
char str[110];
int a[110];
void my_print(int num)
{
    if(num < 0) printf("(%d)", num);
    else        printf("%d", num);
}
void euq_print(int x, char op, int y, int result)
{
    my_print(x);
    printf(" %c ", op);
    my_print(y);
    printf(" = %d\n", result);
}
int main()
{
    int cnt = 0;
    scanf("%s", str);
    int n = strlen(str);

    int i = 0;
    while(i < n - 3) {
        int base = 0;
        int flag = 1;
        if(str[i] == '-') {
            flag *= -1;
            i++;
        }
        while(str[i] != ',') {
            base = base * 10 + str[i] - '0';
            i++;
        }
        a[cnt++] = base * flag;
      //  printf("%d\n", a[cnt-1]);
        i++; // ���һ��һ���ǣ�
    }

    int min = a[0], max = a[0];
    for(i=0; i<cnt; i++) {
        if(a[i] < min) min = a[i];
        if(a[i] > max) max = a[i];
    }//�����ò���ð�����򷨰�������

    if(str[n-3] == '*') euq_print(max, str[n-3], min, max * min);
    if(str[n-3] == '/') euq_print(max, str[n-3], min, max / min);
    if(str[n-3] == '+') euq_print(max, str[n-3], min, max + min);
    if(str[n-3] == '-') euq_print(max, str[n-3], min, max - min);
    if(str[n-3] == '%') euq_print(max, str[n-3], min, max % min);
    return 0;
}
