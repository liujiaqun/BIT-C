#include <stdio.h>
int main()
{
	int m,n,i,j,a[10001];
	scanf("%d%d",&m,&n);
	a[1]=a[3*n-2]=m;
	for(i=2;i<n+(n+1)/2;i++)
	{
		a[i]=a[i-1]+1;
		if(a[i]>=10)
		   a[i]-=10;
		a[3*n-1-i]=a[i];
	}
	for(i=1;i<3*n-2;i++)
	    printf("%d ",a[i]);
	printf("%d\n",a[3*n-2]);
	for(i=2;i<n;i++)
	{
		for(j=1;j<i;j++)
		    printf(" ");
		printf("%d ",a[i]);
	for(j=i+1;j<3*n-1-i;j++)
	    printf(" ");
	printf("%d\n",a[i]);
	 } 
	if(n!=1)
	{
		for(i=1;i<n;i++)
		    printf(" ");
		for(i=n;i<2*n-1;i++)
		    printf("%d ",a[i]);
		printf("%d\n",a[2*n-1]);
	}
	return 0;
}
