#include <stdio.h>
#include <string.h>
int get_type(char* str,int n)//�ж���������
{
    int i;
    n=strlen(str);
    if(str[n-3]=='+') return 1;//����һ��Ҫע�ⲻҪ�ñ��������������� 
    if(str[n-3]=='-') return 2;
    if(str[n-3]=='*') return 3;
    if(str[n-3]=='/') return 4;
    if(str[n-3]=='%') return 5;
    return 0;
}
int main()
{
    int counter=0,temp1,temp2,num,i=0;
    char s[100];
    int a[100];
    scanf("%s",s);
    num=strlen(s);
    while(i<num-3)//�����ַ����������ִ��ó���
    {
    	int base=0;//baseһ��Ҫ����������� ÿ��������while�͹��㣡���� 
        int flag=1;
        if(s[i]=='-')
        {
            flag*=-1;
            i++;
        }
        /*while(s[i]!=',')
        {
            a[counter]=10*a[counter]+s[i]-'0';
            i++;
        }
        a[counter]*=flag;
        i++;*/
        //�����ǰ�����������������
        while(s[i]!=',')
        {
            base=10*base+s[i]-'0';
            i++;
        }
        a[counter++]=base*flag;
        i++;
    }
    int min=a[0],max=a[0];
    for(i=0;i<counter;i++)
    {
        if(a[i]>max) max=a[i];
        if(a[i]<min) min=a[i];
    }
    int type=get_type(s,num);
    if(type==1&&max>=0&&min>=0) 
	printf("%d + %d = %d\n",max,min,max+min);
	if(type==1&&max>=0&&min<0)
	printf("%d + (%d) = %d\n",max,min,max+min);
	if(type==1&&max<0&&min<0)
	printf("(%d) + (%d) = %d\n",max,min,max+min);
	if(type==2&&max>=0&&min>=0) 
	printf("%d - %d = %d\n",max,min,max-min);
	if(type==2&&max>=0&&min<0)
	printf("%d - (%d) = %d\n",max,min,max-min);
	if(type==2&&max<0&&min<0)
	printf("(%d) - (%d) = %d\n",max,min,max-min);
	if(type==3&&max>=0&&min>=0) 
	printf("%d * %d = %d\n",max,min,max*min);
	if(type==3&&max>=0&&min<0)
	printf("%d * (%d) = %d\n",max,min,max*min);
	if(type==3&&max<0&&min<0)
	printf("(%d) * (%d) = %d\n",max,min,max*min);
	if(type==4&&max>=0&&min>=0) 
	printf("%d / %d = %d\n",max,min,max/min);
	if(type==4&&max>=0&&min<0)
	printf("%d / (%d) = %d\n",max,min,max/min);
	if(type==4&&max<0&&min<0)
	printf("(%d) / (%d) = %d\n",max,min,max/min);
	if(type==5&&max>=0&&min>=0) 
	printf("%d % %d = %d\n",max,min,max%min);
	if(type==5&&max>=0&&min<0)
	printf("%d % (%d) = %d\n",max,min,max%min);
	if(type==5&&max<0&&min<0)
	printf("(%d) % (%d) = %d\n",max,min,max%min);
    
    return 0;
}
