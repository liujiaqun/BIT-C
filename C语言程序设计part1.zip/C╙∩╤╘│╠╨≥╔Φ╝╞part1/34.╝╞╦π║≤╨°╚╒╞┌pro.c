#include <stdio.h>
int mon[][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
               0,31,29,31,30,31,30,31,31,30,31,30,31}; 
int get_day(int year,int month){
	int is_run=(year%4==0&&year%100!=0)||year%400==0;
	return mon[is_run][month];
}
int main()
{
	int year,month,day;
	scanf("%d %d %d",&year,&month,&day);
	int n;
	scanf("%d",&n);
	while(n--){
		int max_day=get_day(year,month);
		day++;
		if(day>max_day){
			day=1;
			month++;
		}
		if(month>12){
			month=1;
			year++;
		}
	}
	printf("%d.%d.%d\n",year,month,day);
	return 0;
}
