#include <stdio.h>

int main()
{
	float c,x,a;
	scanf("%f",&c);
	scanf("%f",&x);
	if(c==1)
	{a=(x-32)*5/9;
	printf("The Centigrade is %.2f\n",a);
	}
	else
	{a=(x*9/5)+32;
	printf("The Fahrenheit is %.2f\n",a);
	}
	return 0;
}
