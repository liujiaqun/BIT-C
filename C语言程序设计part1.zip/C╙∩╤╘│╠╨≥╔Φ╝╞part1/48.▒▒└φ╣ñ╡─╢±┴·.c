#include <stdio.h>
int main()
{
    int m,n,i,j;
    int temp;
    int a[100],b[100],c[100];
    scanf("%d%d",&m,&n);
    if(n<m)
    {
        for(i=0;i<m+n;i++)
            scanf("%d",&a[i]);
        printf("bit is doomed!\n");
    }
    else
    {
        for(i=0;i<m+n;i++)
            scanf("%d",&a[i]);//һ���ǵü�&������
        for(i=n;i>0;i--)
            b[i-1]=a[i+m-1];//���ﲻһ��Ҫ����
        for(i=0;i<m-1;i++)
            for(j=i+1;j<m;j++)
        {
            if(a[i]>a[j])
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }//��a[i]��С
        }
        for(i=0;i<n-1;i++)
            for(j=i+1;j<n;j++)
        {
            if(b[i]>b[j])
            {
                temp=b[i];
                b[i]=b[j];
                b[j]=temp;
            }//��b[i]��С
        }
        int count=0,k=0;
        int flag=-1;
        for(i=0;i<m;i++)
            for(j=flag+1;j<n;j++)
        {
            if(a[i]<=b[j])
                {
                    count++;
                    c[k++]=b[j];//��������Ҫ���
                    flag=j;
                    break;
                }
            else
                continue;
        }
        int sum=0;
        if(count>=m)
        {
            for(k=0;k<m;k++)
                sum+=c[k];
            printf("%d\n",sum);
        }
        else
            printf("bit is doomed!\n");
    }return 0;
}
