//1900.1.1 monday 
#include <stdio.h>
#include <stdlib.h>
int mon[][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
               0,31,29,31,30,31,30,31,31,30,31,30,31};
int main()
{
	int year,month,day,k;
	scanf("%d %d %d",&year,&month,&day);
	int now=1;
	
	for(k=1900;k<year;k++){
	int is_run=(k%4==0&&k%100!=0)||k%400==0;
	now=(now+365+is_run)%7;
	}
	
	if(month<=0||month>=13) 
	printf("month is error.\n");
	else{
		int is_run=(year%4==0&&year%100!=0)||year%400==0;
		for(k=1;k<month;k++)
		now=(now+mon[is_run][k])%7;
		
		if(day<=0||day>mon[is_run][month])
		printf("day is error.\n");
		else{
			now=(now+day-1)%7;
			printf("%d\n",now);
		}
	}
	
	return 0;
}
