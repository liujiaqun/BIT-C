#include <stdio.h>
int main()
{
	int m,n;
	char op;
	scanf("%d %c %d",&m,&op,&n);
	if(op=='+')
	printf("%d\n",m+n);
	if(op=='-')
	printf("%d\n",m-n);
	if(op=='*')
	printf("%d\n",m*n);
	if(op=='/')
	printf("%d\n",m/n);
	if(op=='%')
	printf("%d\n",m%n);
	return 0;
}
