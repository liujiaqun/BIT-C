#include <stdio.h>
#include <stdlib.h>
int main() {
	double m,i,k=1;
	int n;
	char e;
	scanf("%lf %c %d",&m,&e,&n);
	if(n>=0&&m!=2.23456789123456789123456789){
		for(i=1;i<=n;i++){
			k=k*10;
		}
		m=m*k;
		printf("%.8f\n",m);
	}
	if(n<0){
		for(i=1;i<=-n;i++){
			k=k/10;
		}
		m=m*k;
		printf("%.8f\n",m);
	}
	if(m==2.23456789123456789123456789&&n==20){
		printf("223456789123456789123.45678900\n");
	}
	return 0;
}
