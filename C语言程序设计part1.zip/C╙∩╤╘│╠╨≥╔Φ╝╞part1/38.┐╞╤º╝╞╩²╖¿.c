#include <stdio.h>
#include <stdlib.h>
int main()
{
	double m,n;
	char e;
	scanf("%lf %c %lf",&m,&e,&n);
	int i,k=1;
	if(n>0)
	{
		for(i=1;i<=n;i++)
		k=k*10;
		printf("%.8lf\n",m*k);
	}
	if(n==0)
	printf("%.8lf\n",m);
	if(n<0)
	{
		for(i=-n;i<0;i++)
		k=k/10;
		print("%.8lf\n",m*k);
	}
	return 0;
}
