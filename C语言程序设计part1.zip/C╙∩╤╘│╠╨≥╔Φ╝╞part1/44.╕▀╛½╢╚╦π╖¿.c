#include<stdio.h>
#include<string.h>
char s1[510], s2[510], s[1010];
int ans[510];
void add(char* s1, int n1, char* s2, int n2) {
    int max_num = n1 > n2 ? n1 : n2;//��Ŀ����
    int i = 0;
    int k = 0;
    while(i<max_num) {
        int x1 = 0, x2 = 0;//ÿ��λ���㶼Ҫ�ȳ�ʼ��
        if(i<n1) x1 = s1[n1-1-i] - '0';
        if(i<n2) x2 = s2[n2-1-i] - '0';
        ans[i++] = (x1 + x2 + k) % 10;//����λ
        k = (x1 + x2 + k) / 10;//�����λ

    }
    if(k) ans[i++] = k;

    i -= 1;
    for(; i>=0; i--) printf("%d", ans[i]);
    printf("\n");
    return;
}

int cmp(char* s1, int n1, char* s2, int n2) {
    if(n1 == n2) {
        for(int i=0; i<n1; i++)
            if(s1[i] != s2[i])
                return s1[i] > s2[i];//������Ү������
        return 1;
    }
    else return n1 > n2;
}

void sub(char* s1, int n1, char* s2, int n2) {
    int max_num = n1;
    int i = 0;
    int k = 0;
    while(i<max_num) {
        int x1 = 0, x2 = 0;
        if(i<n1) x1 = s1[n1-1-i] - '0';
        if(i<n2) x2 = s2[n2-1-i] - '0';
       // printf("\nx1:%d x2:%d\n", x1, x2);
        ans[i++] = (x1 + 10 - x2 + k) % 10;
        if(x1 - x2 + k < 0) k = -1;
        else                k = 0;
    }

    i -= 1;
    for(; i>=0; i--) {
        if(ans[i] != 0)
            break;//ֱ��������������i
    }
    if(i < 0) printf("0");
    else {
        for(; i>=0; i--)
            printf("%d", ans[i]);
    }
    printf("\n");
}
int main()
{
    int k; scanf("%d\n", &k);
    while(k--) {
        gets(s);//��������Getsû��scanf������ͱ�����scanf("%d\n", &k); ���ʹ��scanf�����Բ���\n �㿴��ȫ������Ҳ����������
        int n = strlen(s);

        int i = 0;
        char op;
        int n1 = 0, n2 = 0;
        for(i=0; i<n; i++) {
            if(s[i]>='0' && s[i]<='9')
                s1[n1++] = s[i];
            else {
                op = s[i++];
                break;
            }
        }
        for(; i<n; i++) s2[n2++] = s[i];

        if(op == '+') add(s1, n1, s2, n2);
        else          {
            if(cmp(s1, n1, s2, n2))
                sub(s1, n1, s2, n2);
            else {
                printf("-");
                sub(s2, n2, s1, n1);
            }
        }
    }
    return 0;
}
