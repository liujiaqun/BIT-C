#include <stdio.h>

int main()
{
	int m,n;
	char op;
	scanf("%d %c %d",&m,&op,&n);
	switch(op)
    {   case'+':
    	printf("%d\n",m+n);
    	break;
    	    case'-':
    		printf("%d\n",m-n);
    		break;
    		    case'*':
    			printf("%d\n",m*n);
    			break;
    			    case'/':
    				printf("%d\n",m/n);
    				break;
    				    case'%':
    					printf("%d\n",m%n);
    					break;
    			
	}
	return 0;
}
