#include <stdio.h>
#include <math.h>
int main()
{
    double x,x1,x2;
    double e;
    scanf("%f\n%lf",&x,&e);
    x1=x/2;
    x2=(x1+x/x1)/2;
    do
    {
        x1=x2;
        x2=(x1+x/x1)/2;
    }
    while(fabs(x1-x2)<e);
    printf("%.8lf\n",x2);
    return 0;
}
