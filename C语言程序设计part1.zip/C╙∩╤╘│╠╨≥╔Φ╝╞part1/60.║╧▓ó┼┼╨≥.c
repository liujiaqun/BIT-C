#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int merge_sort(char *a,char *b,char *c);
int main(int argc, char *argv[]) {

    char a[100];
    char b[100];
    char c[200];
    gets(a);
    gets(b);
    merge_sort(a,b,c);
    puts(c);
    return 0;
}
int merge_sort(char *a,char *b,char *c)
{
    strcat(a,b);
    int n=strlen(a);
    int i,j;
    for(i=0;i<n;i++)
        for(j=i+1;j<n;j++)
    {
        if(a[i]>=a[j])
        {
            char c=a[i];
            a[i]=a[j];
            a[j]=c;
        }
    }
    strcpy(c,a);
    return 0;
}
