#include <stdio.h>
#include <string.h>
int main()
{
    int n,N;
    int i,n1,n2;
    char s1[500],s2[500],s[1001];
    char c;
    int a1[500],a2[500],a3[501];
    scanf("%d",&n);
    while(n--)
    {
        scanf("%s",&s);
        N=strlen(s);
        int flag=-1;
        for(i=0;i<N;i++)
        {
            flag++;
            if(s[i]=='+'||s[i]=='-')
                break;
        }
        n1=flag;
        n2=N-n1-1;                       printf("%d/%d/%d\n",N,n1,n2);
        c=s[n1];                              printf("%c\n",c);
        for(i=0;i<n1;i++)
            s1[i]=s[i];
        for(i=0;i<n2;i++)
            s2[i]=s[i+n1+1];
    for(i=0;i<n1;i++)
        a1[i]=s1[i]-'0';
    for(i=0;i<=n2;i++)
        a2[i]=s2[i]-'0';
                                         for(i=0;i<n1;i++) printf("%d",a1[i]);
                                         printf("\n");
                                         for(i=0;i<n2;i++) printf("%d",a2[i]);
                                         printf("\n");
        if(c=='+')//�ӷ�����
        {
            if(n1==n2)
            {
                for(i=n1-1;i>=0;i--)
                {
                    a3[i+1]+=(a1[i]+a2[i])%10;
                    if((a1[i]+a2[i]>=10)&&i!=0) a3[i]++;
                    if((a1[i]+a2[i]==9)&&i!=0&&(a1[i+1]+a2[i+1]>=10)) {a3[i]++;a3[i+1]=a3[i+1]%10;}
                    if(a1[0]+a2[0]>=10) a3[0]=1;
                    else a3[0]=0;
                }
                if(a3[0]==0)
                {
                    for(i=1;i<n1+1;i++)
                        printf("%d",a3[i]);
                }
                if(a3[0]==1)
                {
                    for(i=0;i<n1+1;i++)
                        printf("%d",a3[i]);
                }
                printf("\n");
            }
            if(n1<n2)
            {
                for(i=n2-1;i>=n2-n1;i--)
                    a1[i]=a1[i-(n2-n1)];//����һ��Ҫ���򣬷�����234���ǳ�000222������
                for(i=0;i<n2-n1;i++)
                    a1[i]=0;                             for(i=0;i<n2;i++) printf("%d",a1[i]); printf("�����Ǽ���ǰ�����a1");
                for(i=n2-1;i>=0;i--)
                {
                    a3[i+1]+=(a1[i]+a2[i])%10;
                    if((a1[i]+a2[i]>=10)&&i!=0) a3[i]++;
                    if((a1[i]+a2[i]==9)&&i!=0&&(a1[i+1]+a2[i+1]>=10)) {a3[i]++;a3[i+1]=a3[i+1]%10;}
                    if(a1[0]+a2[0]>=10) a3[0]=1;
                    else a3[0]=0;
                }
                if(a3[0]==0)
                {
                    for(i=1;i<n2+1;i++)
                        printf("%d",a3[i]);
                }
                if(a3[0]==1)
                {
                    for(i=0;i<n2+1;i++)
                        printf("%d",a3[i]);
                }
                printf("\n");

            }
            if(n1>n2)
            {
               for(i=n1-1;i>=n1-n2;i--)
                    a2[i]=a2[i-(n1-n2)];//����һ��Ҫ���򣬷�����234���ǳ�000222������
                for(i=0;i<n1-n2;i++)
                    a2[i]=0;                             for(i=0;i<n2;i++) printf("%d",a1[i]); printf("�����Ǽ���ǰ�����a1");
                for(i=n1-1;i>=0;i--)
                {
                    a3[i+1]+=(a1[i]+a2[i])%10;
                    if((a1[i]+a2[i]>=10)&&i!=0) a3[i]++;
                    if((a1[i]+a2[i]==9)&&i!=0&&(a1[i+1]+a2[i+1]>=10)) {a3[i]++;a3[i+1]=a3[i+1]%10;}
                    if(a1[0]+a2[0]>=10) a3[0]=1;
                    else a3[0]=0;
                }
                if(a3[0]==0)
                {
                    for(i=1;i<n1+1;i++)
                        printf("%d",a3[i]);
                }
                if(a3[0]==1)
                {
                    for(i=0;i<n1+1;i++)
                        printf("%d",a3[i]);
                }
                printf("\n");
            }
        }
        if(c=='-')//��������
        {

        }
        char s1[500]={0};
        char s2[500]={0};
        char s[1001]={0};
        int a1[500]={0};
        int a2[500]={0};
        int a3[501]={0};
    }return 0;
}
