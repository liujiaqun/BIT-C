#include <stdio.h>
int main()
{
    int a1,b,c,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,upc,i,j,k;
    scanf("%d\n%d\n%d",&a1,&b,&c);
    a6=b%10;
    a5=b/10%10;
    a4=b/100%10;
    a3=b/1000%10;
    a2=b/10000;
    a11=c%10;
    a10=c/10%10;
    a9=c/100%10;
    a8=c/1000%10;
    a7=c/10000;
    i=a1+a3+a5+a7+a9+a11;
    j=a2+a4+a6+a8+a10;
    k=(3*i+j-1)%10;
    upc=9-k;
    printf("%d\n",upc);

}
