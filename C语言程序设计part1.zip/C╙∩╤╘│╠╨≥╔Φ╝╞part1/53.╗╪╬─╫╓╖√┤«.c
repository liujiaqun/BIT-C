#include <stdio.h>
#include <string.h>
int f(char* str,int l,int h)
{
    if(l>=h)
        return 1;
    else
    {
        if(str[l]==str[h])
            return f(str,l+1,h-1);
        return 0;
    }
}
int main()
{
    char str[100];
    scanf("%s",str);
    int n=strlen(str);
    if(f(str,0,n-1)) printf("Yes\n");
        else printf("No\n");
    return 0;
}
//��֪��Ϊɶ����س�Ҳ����......
