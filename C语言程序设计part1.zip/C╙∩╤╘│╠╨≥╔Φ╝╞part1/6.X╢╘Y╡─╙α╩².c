#include <stdio.h>

int main() 
{
	int X,Y,a;
	scanf("%d%d",&X,&Y);
	a=X%Y;
	printf("%d\n",a);
	return 0;
}
