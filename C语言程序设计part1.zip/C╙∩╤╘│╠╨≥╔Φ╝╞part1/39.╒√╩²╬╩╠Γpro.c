#include <stdio.h>
int sum,n,k;
void dfs(int now,int pre){
	if(now==n&&n){
		sum++;
		return;
	}
	
	now+=1;
	for(k=0;k<=9;k++){
		int x=pre*10+k;
		if(x%(now*now)==0&&x)
		dfs(now,x);
	}return;

}

int main()
{
	scanf("%d",&n);
	dfs(0,0);
	printf("%d\n",sum); 
	return 0;
}
