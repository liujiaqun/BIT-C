#include <stdio.h>
#include <math.h>
#include <stdbool.h>
bool is_ok(int x,int n){
	int sum=0;
	int raw_x=x;
	//�ֽ�
	while(x){
		int k=x%10;
		sum+=pow(k,n);
		x/=10;
	} 
	return sum==raw_x;
	 
}
int main()
{
	int n,i;
	scanf("%d",&n);
	int sum=0;
	int a=pow(10,n-1),b=pow(10,n);
	for(i=a;i<b;i++){
		if(is_ok(i,n)){
			printf("%d\n",i);
			sum++;
		}
	}
	if(!sum) puts("No output.");
	return 0;
}
