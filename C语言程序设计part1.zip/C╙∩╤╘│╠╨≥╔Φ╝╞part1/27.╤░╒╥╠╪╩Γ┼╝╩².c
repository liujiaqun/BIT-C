#include <stdio.h>
int main()
{
	int x1,y1,i1,j1=0,a1,b1,c1,d1;
	scanf("%d %d",&x1,&y1);
	if((x1<1000||y1<1000)&&(x1!=0&&y1!=0))
	printf("Error\n");
	else if(x1>=1000&&y1>=1000||x1==y1&&x1!=0)
{
	for(i1=x1;i1<=y1;i1++)
	{
		d1=i1%10;
		c1=i1/10%10;
		b1=i1/100%10;
		a1=i1/1000;
		if(a1!=b1&&a1!=c1&&a1!=d1&&b1!=c1&&b1!=d1&&c1!=d1&&d1%2==0)
		{printf("%d  ",i1);j1++;}
	}
	printf("\n");
	printf("counter=%d\n",j1);
}
    else;
    
    
    
int x2,y2,i2,j2=0,a2,b2,c2,d2;
	scanf("%d %d",&x2,&y2);
	if((x2<1000||y2<1000)&&(x2!=0&&y2!=0))
	printf("Error\n");
	else if(x2>=1000&&y2>=1000||x2==y2&&x2!=0)
{
	for(i2=x2;i2<=y2;i2++)
	{
		d2=i2%10;
		c2=i2/10%10;
		b2=i2/100%10;
		a2=i2/1000;
		if(a2!=b2&&a2!=c2&&a2!=d2&&b2!=c2&&b2!=d2&&c2!=d2&&d2%2==0)
		{printf("%d  ",i2);j2++;}
	}
	printf("\n");
	printf("counter=%d\n",j2);
}
    else;
    
    
    
int x3,y3,i3,j3=0,a3,b3,c3,d3;
	scanf("%d %d",&x3,&y3);
	if((x3<1000||y3<1000)&&(x3!=0&&y3!=0))
	printf("Error\n");
	else if(x3>=1000&&y3>=1000||x3==y3&&x3!=0)
{
	for(i3=x3;i3<=y3;i3++)
	{
		d3=i3%10;
		c3=i3/10%10;
		b3=i3/100%10;
		a3=i3/1000;
		if(a3!=b3&&a3!=c3&&a3!=d3&&b3!=c3&&b3!=d3&&c3!=d3&&d3%2==0)
		{printf("%d  ",i3);j3++;}
	}
	printf("\n");
	printf("counter=%d\n",j3);
}
    else;
	return 0;
}
