#include <stdio.h>
int main()
{
	int a,n,m=1;
	scanf("%d",&n);
	if(n==1)
	printf("The monkey got 1 peach in first day.\n");
	else
	{
		for(a=n-1;a>=1;a--)
	    {m=2*(m+a);}//d2=d2/2+n-1+d1
	    printf("The monkey got %d peaches in first day.\n",m);
	}
	return 0;
}
