#include <stdio.h>
int main()
{
	int y,m,d,n,i;
	int a[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
	scanf("%d%d%d",&y,&m,&d);
    scanf("%d",&n);
    if((y%4==0&&y%100!=0)||(y%400==0))
    a[2]++;
    n=n+d;
    for(i=m;i<=12;i++)
    {
    	n=n-a[i];
    	if(i==12&&n>0)
    	{
    		y++;
    		if((y%4==0&&y%100!=0)||(y%400==0))
    		a[2]=29;
    		else
    		a[2]=28;
    		i=0;
		}
		else{
			if(n<=0)
			{
				m=i;
				d=n+a[i];
				break;
			}
		}
	}printf("%d.%d.%d\n",y,m,d);
	
	return 0;
}
