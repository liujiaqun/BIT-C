#include <stdio.h>

int main()
{
	char a;
	scanf("%d",&a);
	printf("%c\n",a);
	return 0;
}
