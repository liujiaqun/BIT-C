#include <stdio.h>
int main()
{
	int i,j,n;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
{
	if(i==1)
	{for(j=1;j<=2*n-1;j++)
	printf("*");}
	else
	{for(j=1;j<=i-1;j++)
	printf(" ");
	printf("*");
	for(j=1;j<=2*n-1-2*i;j++)
	printf(" ");
	if(i!=n)
	printf("*");
	}printf("\n");
}
    
	return 0;
}
