#include <stdio.h>
int main()
{
	long long a,b;
	char op;
	scanf("%lld %lld %c",&a,&b,&op);
	switch(op)
	{
	
	     case'+':
		     {printf("%lld\n",a+b);
		 break;
	      	 }
		 case'-':
		     {printf("%lld\n",a-b);
		 break;
		     }
		 case'*':
		     {printf("%lld\n",a*b);
		 break;
		     }
		 case'/':
		     {if(b==0)
		printf("Go to hell!\n");
		else
		printf("%lld\n",a/b);
		 break;
		     }
    }
		
	return 0;
}
