#include<stdio.h>
#include<string.h>
char str[12010][50];
int cnt = 0;
int find(char*  tmp) {
    for(int i=0; i<cnt; i++)
        if(strcmp(str[i], tmp)==0)
            return i;
    strcpy(str[cnt++], tmp);
    return -1;
}
int main()
{
    int n;
    scanf("%d",&n);
    while(n--)
    {
        char s[100];
    while(gets(s)) {
        int n = strlen(s);
        int i = 0;
        while(i < n) {
            if(s[i]>='a' && s[i]<='z' || s[i]>='A' && s[i]<='Z') {
                char tmp[100]; int k = 0;
                while(i<n && (s[i]>='a' && s[i]<='z' || s[i]>='A' && s[i]<='Z')) {
                    tmp[k++] = s[i++];
                }
                tmp[k] = '\0';
                int index = find(tmp);
                if(index == -1) printf("%s", tmp);
                else            printf("%d", index+1);
            }
            else printf("%c", s[i++]);
        }
        printf("\n");
    }
    }
    return 0;
}
