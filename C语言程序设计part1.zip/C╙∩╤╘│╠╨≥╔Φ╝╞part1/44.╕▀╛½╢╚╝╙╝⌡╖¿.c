#include <stdio.h>
#include <string.h>
int main()
{
    int n,N;
    int i,n1,n2;
    char s1[500],s2[500],s[1001];
    char c;
    int a1[500],a2[500],a3[501];
    scanf("%d",&n);
    while(n--)
    {
        scanf("%s",s);
        N=strlen(s);
        int flag=-1;
        for(i=0;i<N;i++)
        {
            flag++;
            if(s[i]=='+'||s[i]=='-')
                break;
        }
        n1=flag;
        n2=N-n1-1;                       printf("%d/%d/%d\n",N,n1,n2);
        c=s[n1];                              printf("%c\n",c);
        for(i=0;i<n1;i++)
            s1[i]=s[i];
        for(i=0;i<n2;i++)
            s2[i]=s[i+n1+1];
    for(i=0;i<n1;i++)
        a1[i]=s1[i]-'0';
    for(i=0;i<=n2;i++)
        a2[i]=s2[i]-'0';
                                         for(i=0;i<n1;i++) printf("%d",a1[i]);
                                         printf("\n");
                                         for(i=0;i<n2;i++) printf("%d",a2[i]);
                                         printf("\n");
        if(c=='+')//�ӷ�����
        {
            if(n1==n2)
            {
                for(i=n1-1;i>=0;i--)
                {
                    a3[i+1]+=(a1[i]+a2[i])%10;
                    if((a1[i]+a2[i]>=10)&&i!=0) a3[i]++;
                    if((a1[i]+a2[i]==9)&&i!=0&&(a1[i+1]+a2[i+1]>=10)) {a3[i]++;a3[i+1]=a3[i+1]%10;}
                    if(a1[0]+a2[0]>=10) a3[0]=1;
                    else a3[0]=0;
                }
                if(a3[0]==0)
                {
                    for(i=1;i<n1+1;i++)
                        printf("%d",a3[i]);
                }
                if(a3[0]==1)
                {
                    for(i=0;i<n1+1;i++)
                        printf("%d",a3[i]);
                }
                printf("\n");
            }
            if(n1>n2)
            {
                for(i=n1-1;i>=n1-n2;i--)
                {
                    a3[i]=(a1[i]+a2[i])%10;
                    if((a1[i]+a2[i]>=10)&&i!=(n1-n2)) a3[i-1]++;
                    if(a1[n1-n2]+a2[n1-n2]>=10) a3[n1-n2-1]++;
                    else a3[n1-n2-1]=a3[n1-n2-1]+0;
                }
                for(i=0;i<n1-n2-1;i++)
                    printf("%d",a1[i]);
                for(i=0;i<=n2;i++)
                {
                    a3[i]=a3[i+n1-n2];
                    printf("%d",a3[i]);
                }
                printf("\n");
            }
            if(n1<n2)
            {
                int temp;
                int tmp[500];
                temp=n1;
                n1=n2;
                n2=temp;
                for(i=0;i<500;i++)//����ҵ�һλһλ������滻Ҳ��һλһλ�滻������
                {
                    tmp[i]=a1[i];
                a1[i]=a2[i];
                a2[i]=tmp[i];
                }
                for(i=n1-1;i>=n1-n2;i--)
                {
                    a3[i+1]=(a1[i]+a2[i])%10;
                    if((a1[i]+a2[i]>=10)&&i!=(n1-n2)) a3[i]++;
                    if(a1[n1-n2]+a2[n1-n2]>=10) a3[n1-n2]++;
                    else a3[n1-n2]=a3[n1-n2]+0;
                }
                for(i=0;i<n1-n2-1;i++)
                    printf("%d",a1[i]);
                for(i=0;i<=n2;i++)
                {
                    a3[i]=a3[i+n1-n2];
                    printf("%d",a3[i]);
                }
                printf("\n");
            }
        }
        if(c=='-')//��������
        {
            if(n1=n2)
            {
                int a=strcmp(s1,s2);
                if(a>0)//˵��s1>s2
                {
                    for(i=n1-1;i>=0;i--)
                        {
                            if(a1[i]<0)
                                a1[i]=9;
                            if(a1[i]<a2[i])
                            {
                                a1[i]=10+a1[i];
                                a1[i-1]--;
                                a3[i]=a1[i]-a2[i];
                            }
                        }
                }
                int l=0;
                while(a3[l]==0) l++;
                for(i=l;i<n1;i++)
                    printf("%d",a3[i]);
                printf("\n");

                if(a==0)//˵��s1=s2
                printf("0");

                if(a<0)//˵��s1<s2
                {
                    int tmp[500];
                    for(i=0;i<500;i++)//����ҵ�һλһλ������滻Ҳ��һλһλ�滻������
                {
                    tmp[i]=a1[i];
                a1[i]=a2[i];
                a2[i]=tmp[i];
                }
                    for(i=n1-1;i>=0;i--)
                        {
                            if(a1[i]<0)
                                a1[i]=9;
                            if(a1[i]<a2[i])
                            {
                                a1[i]=10+a1[i];
                                a1[i-1]--;
                                a3[i]=a1[i]-a2[i];
                            }
                        }

                }
                printf("-");
                int k=0;
                while(a3[k]==0) k++;
                for(i=k;i<n1;i++)
                    printf("%d",a3[i]);
                printf("\n");
            }
            if(n1>n2)
            {
                for(i=n1-1;i>=n1-n2;i--)
                {
                    if(a1[i]<0)
                        a1[i]=9;
                    if((a1[i]<a2[i])&&i!=(n1-n2))
                    {
                        a1[i]=10+a1[i];
                        a1[i-1]--;
                        a3[i]=a1[i]-a2[i];
                    }
                    if(a1[i]>=a2[i])
                        a3[i]=a1[i]-a2[i];
                    if(a1[n1-n2]<a2[n1-n2])
                    {
                        a1[i]=10+a1[i];
                        a1[i-1]--;
                        a3[i]=a1[i]-a2[i];
                        a3[n1-n2-1]=a1[n1-n2]+10-a2[n1-n2]-1;
                    }
                }
                for(i=0;i<n1-n2-1;i++)
                    printf("%d",a1[i]);
                printf("%d",a3[n1-n2-1]);
                for(i=n1-n2;i<n1;i++)
                    printf("%d",a3[i]);
                printf("\n");
            }
            if(n1<n2)
            {
                int temp;
                int tmp[500];
                temp=n1;
                n1=n2;
                n2=temp;
                for(i=0;i<500;i++)//����ҵ�һλһλ������滻Ҳ��һλһλ�滻������
                {
                    tmp[i]=a1[i];
                a1[i]=a2[i];
                a2[i]=tmp[i];
                }
                for(i=n1-1;i>=n1-n2;i--)
                {
                    if(a1[i]<0)
                        a1[i]=9;
                    if((a1[i]<a2[i])&&i!=(n1-n2))
                    {
                        a1[i]=10+a1[i];
                        a1[i-1]--;
                        a3[i]=a1[i]-a2[i];
                    }
                    if(a1[i]>=a2[i])
                        a3[i]=a1[i]-a2[i];
                    if(a1[n1-n2]<a2[n1-n2])
                    {
                        a1[i]=10+a1[i];
                        a1[i-1]--;
                        a3[i]=a1[i]-a2[i];
                        a3[n1-n2-1]=a1[n1-n2]+10-a2[n1-n2]-1;
                    }
                }
                for(i=0;i<n1-n2-1;i++)
                    printf("%d",a1[i]);
                printf("%d",a3[n1-n2-1]);
                for(i=n1-n2;i<n1;i++)
                    printf("%d",a3[i]);
                printf("\n");
            }
        }
    }return 0;
}
