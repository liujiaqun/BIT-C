#include <stdio.h>
int f(int m,int n)
{
    if(m%n==0) return n;
    return f(n,(m%n));
}
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    int k=f(m,n);
    printf("%d\n",k);
    return 0;
}
