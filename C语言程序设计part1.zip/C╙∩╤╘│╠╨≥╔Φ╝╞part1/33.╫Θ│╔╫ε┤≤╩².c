#include <stdio.h>
#include <string.h>
int main()
{
	int i,j;
	char number[10],temp;
	scanf("%s",number);
	for(i=0;i<strlen(number)-1;i++)
	for(j=0;j<strlen(number)-1-i;j++)
	if(number[j]<number[j+1])
	{
		temp=number[j];
		number[j]=number[j+1];
		number[j+1]=temp;
	}
	printf("%s\n",number);
	
	return 0;
}
