#include <stdio.h>
#include <string.h>
int main()
{
	char a[100],b[100];
	int i,j,s,q,x;
	gets(a);
	x=strlen(a);
	for(s=0,q=1,x--;'0'<=a[x]&&a[x]<='9';x--,q*=10)
		s=s+(a[x]-'0')*q;
	if(a[x]=='-')
		s=-s;
	for(i=j=0;a[i]!=' ';i++)
	{
		if(a[i]<='9'&&a[i]>='0')
		{
			b[j]=a[i];
			j++;
		}
	}
	if(s<=0)
	{
		for(i=s;i<=s+8;i++)
		{
			if(i<0)printf("0");
			if(i>=0&&i<j)printf("%c",b[i]);
			if(i==s)printf(".");
			if(i>=j)printf("0");
		}
		printf("\n");
	}
	if(s>0)
	{
		for(i=0;i<=s+8;i++)
		{
			if(i<j)printf("%c",b[i]);
			if(i>=j)printf("0");
			if(i==s)printf(".");
		}
		printf("\n");
	}
	return 0;
}

