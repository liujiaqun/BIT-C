#include <stdio.h>
int main() 
{
	printf("Welcome\nto\nBeijing.\n");
	return 0;
}
