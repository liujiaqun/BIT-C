#include <stdio.h>
int main()
{
    int n,k,i,j;
    scanf("%d",&n);
    int l=0;
    int base;
    int flag=1;
    int a[20][20]={{0}};
    for(k=1;k<=2*n-1;k++)
    {
        int h=k-1;
        if(k<=n)//��벿��
        {
            if(k%2!=0)//k��
                {
                    base=0;
                    while(h>=0)
                    {
                        a[h][base]=flag++;
                        base++;
                        h--;
					}
                }
            else if(k%2==0)//kż
                {
                    base=0;
                    while(h>=0)
                    {
                        a[base][h]=flag++;
                        base++;
                        h--;
					}
                }
        }
        else//�Ұ벿��
        {
            int m=2*n-k;//��kб����m����
            int p=k-n;//����or�������
            int q=n-1;
            if(k%2!=0)//k��
                {
                    while(m--)
                        a[q--][p++]=flag++;
                }
            if(k%2==0)//kż
                {
                    while(m--)
                        a[p++][q--]=flag++;
                }
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        printf("%3d",a[i][j]); 
	    printf("\n");		   	
	}
	return 0;
}
