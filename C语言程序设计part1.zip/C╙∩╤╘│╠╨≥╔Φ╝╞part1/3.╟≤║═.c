#include <stdio.h>
int main() 
{
	int A,B,C;
	scanf("%d",&A);
	scanf("%d",&B);
	    C=A+B;
	printf("%d+%d=%d\n",A,B,C);
	return 0;
}
