#include <stdio.h>
int main()
{
	//1.8x=1.5y=2z;
	//x=10/9*z;
	//y=4/3*z;
	
	//0.1x+0.5y+z=t*10;
	//16/9*z=10*t;
	
	int t;
	scanf("%d",&t);
	if(10*t*9%16==0){
		int ans=10*t*9/16;
		printf("%d,%d,%d\n",ans*10/9,ans*4/3,ans);
	} 
	else puts("No change.");
	return 0;
}
