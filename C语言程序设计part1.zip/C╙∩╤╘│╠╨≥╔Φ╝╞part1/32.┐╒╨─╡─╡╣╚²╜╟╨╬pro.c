#include <stdio.h>
int main()
{
	int n,i,j;
	scanf("%d",&n);
	for(i=1;i<=2*n-1;i++)
	   printf("*");
	printf("\n");
	for(i=n-1;i>=1;i--)
	{
		for(j=1;j<=n-i;j++)
		   printf(" ");
		printf("*");
		for(j=1;j<=2*i-3;j++)
		   printf(" ");
		if(i!=1)
		   printf("*\n");
	}
	if(n!=1)
	    printf("\n");
	return 0;
}
