//1900.1.1 monday
#include <stdio.h>
int mon[][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
               0,31,29,31,30,31,30,31,31,30,31,30,31};
int main()
{
	int year,k,now=1;
	scanf("%d",&year);
	for(k=1900;k<year;k++){
		int is_run=(k%4==0&&k%100!=0)||k%400==0;
		now=(now+365+is_run)%7;
	}
	int is_run=(year%4==0&&year%100!=0)||year%400==0;
	for(k=1;k<=4;k++)
	    now=(now+mon[is_run][k])%7;
	int ans=(7-now)%7+7+1;
	printf("%d\n",ans);
	return 0;
}
