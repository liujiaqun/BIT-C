#include <stdio.h>
int main()
{
	int X,Y,Z,A;
	scanf("%d",&X);
	scanf("%d",&Y);
	scanf("%d",&Z);
	A=X*Y+Z;
	printf("%d\n",A);
	return 0;
}
