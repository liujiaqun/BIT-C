#include <stdio.h>
int f(int l,int h)
{
    if(l==h) return h;
    else return h+f(l,h-1);
}
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    int sum=f(m,n);
    printf("The sum from %d to %d is %d.\n",m,n,sum);
    return 0;
}
